# PERUNA™ — Elämänhallintaa, mutta väärin.

PERUNA™ on absurdi, täysin offline-toimiva Android-sovellus: peruna solmiossa antaa virallisen
kuuloisia mutta täysin turhia tuomioita, hyödyttömiä tehtäviä ja merkityksettömiä saavutuksia.

* Kotlin + Jetpack Compose, yksi moduuli, ei ulkopuolisia palveluja
* **Ei verkkoa, ei tiliä, ei mainoksia, ei seurantaa, ei yhtään Android-oikeutta**
* 156 tuomiota (sis. harvinaiset ja salaiset), 34 tehtävää, 21 saavutusta
* Jaa tuomio tekstinä tai kuvakorttina (Androidin jakovalikko)

> Kaikki sisältö on kuvitteellista huumoria. PERUNA ei ole viranomainen, lääkäri tai oikea peruna.

---

## A. APK:n teko pelkällä puhelimella (GitHub Actions)

Tarvitset ilmaisen GitHub-tilin. Mitään ei tarvitse asentaa.

1. **Luo repo.** Mene selaimella osoitteeseen github.com → `+` → **New repository**.
   Anna nimi (esim. `peruna`), valitse Private tai Public, paina **Create repository**.
2. **Lisää workflow-tiedosto.** Repossa: **Add file → Create new file**.
   Kirjoita tiedoston nimi-kenttään täsmälleen `.github/workflows/build-apk.yml`
   (kauttaviivat luovat kansiot automaattisesti). Liitä sisään `build-apk.yml`-tiedoston koko sisältö
   ja paina **Commit changes**.
3. **Lataa projekti.** **Add file → Upload files** → valitse `peruna-android-project.zip`
   (älä pura sitä) → **Commit changes**.
4. **Odota rakennusta.** Avaa **Actions**-välilehti. Työ "Build PERUNA APK" käynnistyy itse
   ja kestää ensimmäisellä kerralla noin 5–10 minuuttia. Vihreä ✓ = onnistui. Punainen ✗ = avaa
   työ ja katso virheilmoitus.
   Voit käynnistää rakennuksen myös käsin: Actions → Build PERUNA APK → **Run workflow**.
5. **Lataa APK.** Kaksi tapaa:
   * **Releases** (helpoin): repon etusivulla oikealla **Releases** → uusin `PERUNA debug build N`
     → napauta `PERUNA-debug.apk`.
   * **Artifact**: Actions → avaa onnistunut ajo → alhaalla **Artifacts** → `peruna-debug-apk`
     (zip, jonka sisällä `app-debug.apk`; pura se puhelimen Tiedostot-sovelluksella).

## B. Asennus puhelimeen

1. Avaa ladattu `.apk` (Tiedostot-sovelluksesta tai selaimen latauksista).
2. Android kysyy lupaa asentaa tuntemattomista lähteistä: paina **Asetukset** ja salli asennus
   siitä sovelluksesta, jolla avasit tiedoston (selain tai Tiedostot). Palaa takaisin ja paina **Asenna**.
3. Jos Play Protect varoittaa tuntemattomasta sovelluksesta, valitse **Asenna silti**
   (APK on debug-versio, jota et ole allekirjoittanut itse Play Kauppaa varten).
4. Avaa **PERUNA™**. Sovellus toimii myös lentokonetilassa.

**Päivitys:** rakenna uusi APK ja asenna se vanhan päälle. Projektissa on kiinteä debug-avain
(`app/debug.keystore`), joten päivitys onnistuu ja tallennettu edistyminen säilyy.

**Poisto:** pidä sovelluksen kuvaketta pohjassa → *Sovellustiedot* → **Poista**
(tai Asetukset → Sovellukset → PERUNA™ → Poista asennus).

## C. Rakennus omalla koneella (Android Studio)

1. Asenna [Android Studio](https://developer.android.com/studio) (uusin vakaa).
2. **File → Open** ja valitse tämä kansio (`settings.gradle.kts` on sen juuressa).
   Studio lataa tarvittavat osat itse; valitse pyydettäessä JDK 17.
3. Paina **Run ▶** (puhelin USB-kaapelilla, USB-vianetsintä päällä) tai
   **Build → Build APK(s)**.
4. APK löytyy polusta `app/build/outputs/apk/debug/app-debug.apk`.

Komentoriviltä (vaatii Gradle 8.9+ ja JDK 17 sekä Android SDK:n):

```
gradle assembleDebug
gradle testDebugUnitTest
```

(Halutessasi luo Gradle wrapper: `gradle wrapper --gradle-version 8.10.2`.)

## D. Julkaisu-APK (release) myöhemmin

1. Luo avain (säilytä tiedosto ja salasanat turvallisesti, älä lisää niitä GitHubiin):
   `keytool -genkeypair -v -keystore peruna-release.jks -alias peruna -keyalg RSA -keysize 2048 -validity 10000`
2. Lisää `app/build.gradle.kts`:n `android { }` -lohkoon:

   ```kotlin
   signingConfigs {
       create("release") {
           storeFile = file(System.getenv("PERUNA_KEYSTORE") ?: "peruna-release.jks")
           storePassword = System.getenv("PERUNA_STORE_PASSWORD")
           keyAlias = "peruna"
           keyPassword = System.getenv("PERUNA_KEY_PASSWORD")
       }
   }
   buildTypes {
       release {
           signingConfig = signingConfigs.getByName("release")
           // isMinifyEnabled = true  // valinnainen
       }
   }
   ```
3. Aja `gradle assembleRelease`. Tulos: `app/build/outputs/apk/release/app-release.apk`.
   Play Kauppaa varten tee `gradle bundleRelease` (AAB).

## Projektin rakenne

```
app/src/main/java/fi/peruna/app/
  MainActivity.kt          käynnistys + takaisin-nappi
  data/Content.kt          KAIKKI tekstit: tuomiot, tehtävät, tilarivit  ← muokkaa tätä
  data/Achievements.kt     saavutukset ja niiden avaussäännöt
  data/*Repository.kt      arvonta (ei toistoja), tallennus (SharedPreferences)
  ui/                      ruudut (Home, Judgment, Task, Achievements, Settings) ja retrokomponentit
  sharing/                 tekstin ja kuvakortin jakaminen
app/src/test/              yksikkötestit (sisältö, arvonta, saavutukset)
.github/workflows/         build-apk.yml
```

Uuden tuomion lisäys: avaa `Content.kt`, lisää rivi `Judgment("J999", "ARKI", "Otsikko", "Teksti"),`
listaan (anna uniikki ID, älä käytä pilkkua ID:ssä). Tehtävät samoin `PerunaTask(...)`.

## Yksityisyys ja oikeudet

Sovellus ei pyydä mitään oikeuksia eikä käytä verkkoa. Puhelimeen tallentuu vain paikallinen tila:
tuomio- ja tehtävälaskurit, avatut saavutukset, viimeisimmät tuomio-ID:t ja muutama salainen lippu.
Asetukset → **Nollaa edistyminen** poistaa kaiken (vahvistuksen jälkeen).
Jakaessa kuvakortin tiedosto kirjoitetaan sovelluksen omaan välimuistiin ja jaetaan väliaikaisella
FileProvider-linkillä.

## Salaisuuksia (spoilerit)

Jotkin tuomiot ovat harvinaisia, ja muutama salainen tapahtuu virstanpylväillä (10., 42., 100. tuomio)
tai satunnaisesti. Etusivulla on myös yksi piilotettu paikka. Ei kerrota enempää.
