package fi.peruna.app.sharing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import fi.peruna.app.BuildConfig
import fi.peruna.app.data.ShownJudgment

/** Piirtää jaettavan tuomiokortin bitmapiksi. Pelkkää android.graphics-koodia, ei tiedostoja. */
object CardRenderer {

    private const val W = 1080
    private const val H = 1350

    private val CHROME = Color.parseColor("#C9C5B8")
    private val OLIVE = Color.parseColor("#3F4A2A")
    private val TERMINAL = Color.parseColor("#9BE564")
    private val PAPER = Color.parseColor("#F6F3E7")
    private val INK = Color.parseColor("#1F1F1A")
    private val INK_SOFT = Color.parseColor("#4A4A40")
    private val STAMP = Color.parseColor("#B3261E")
    private val POTATO = Color.parseColor("#D9B26A")
    private val POTATO_DARK = Color.parseColor("#6B4F1D")

    fun render(shown: ShownJudgment): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(CHROME)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        // Otsikkopalkki
        fill.color = OLIVE
        c.drawRect(40f, 40f, 1040f, 130f, fill)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = TERMINAL
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 42f
        }
        c.drawText("PERUNA OS / v" + BuildConfig.VERSION_NAME, 70f, 98f, titlePaint)

        // Paperipaneeli
        fill.color = PAPER
        c.drawRect(40f, 130f, 1040f, 1210f, fill)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = INK
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        c.drawRect(40f, 130f, 1040f, 1210f, border)

        // Asiakirjanumero ja luokka
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val casePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = INK_SOFT
            typeface = mono
            textSize = 34f
        }
        c.drawText("TAPAUS " + shown.caseNumber, 80f, 205f, casePaint)
        casePaint.color = OLIVE
        c.drawText("LUOKKA: " + shown.judgment.category, 80f, 255f, casePaint)

        drawPotato(c, 880f, 215f)

        // Otsikko ja leipäteksti: pienennä fonttia, kunnes kaikki mahtuu
        val textWidth = 920
        val availableHeight = 680
        var headSize = 64f
        var bodySize = 46f
        var head = makeLayout(shown.judgment.headline, headSize, true, INK, textWidth)
        var body: StaticLayout? = null
        while (true) {
            head = makeLayout(shown.judgment.headline, headSize, true, INK, textWidth)
            body = if (shown.judgment.body.isNotBlank()) {
                makeLayout(shown.judgment.body, bodySize, false, INK, textWidth)
            } else {
                null
            }
            val bodyHeight = body?.height ?: 0
            val total = head.height + (if (bodyHeight > 0) 30 + bodyHeight else 0)
            if (total <= availableHeight || headSize <= 30f) break
            headSize -= 4f
            bodySize = (bodySize - 3f).coerceAtLeast(26f)
        }
        val finalHead = head
        val finalBody = body
        c.save()
        c.translate(80f, 300f)
        finalHead.draw(c)
        c.restore()
        if (finalBody != null) {
            c.save()
            c.translate(80f, 300f + finalHead.height + 30f)
            finalBody.draw(c)
            c.restore()
        }

        // Luotettavuus
        val relPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = OLIVE
            typeface = mono
            textSize = 30f
        }
        val relLayout = StaticLayout.Builder
            .obtain("LUOTETTAVUUS: " + shown.reliability, 0, ("LUOTETTAVUUS: " + shown.reliability).length, relPaint, 920)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        c.save()
        c.translate(80f, 1210f - 30f - relLayout.height)
        relLayout.draw(c)
        c.restore()

        // Kumileimasin
        drawStamp(c, shown.stamp, 790f, 1060f)

        // Alatunniste
        val footer = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = INK_SOFT
            typeface = mono
            textSize = 32f
            textAlign = Paint.Align.CENTER
        }
        c.drawText("Elämänhallintaa, mutta väärin.", W / 2f, 1280f, footer)

        return bmp
    }

    private fun makeLayout(text: String, size: Float, bold: Boolean, color: Int, width: Int): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        }
        return StaticLayout.Builder
            .obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.12f)
            .build()
    }

    private fun drawStamp(c: Canvas, text: String, cx: Float, cy: Float) {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = STAMP
            alpha = 225
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 46f
            textAlign = Paint.Align.CENTER
        }
        val textW = paint.measureText(text)
        val halfW = textW / 2f + 26f
        val halfH = 44f
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = STAMP
            alpha = 225
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        c.save()
        c.rotate(-8f, cx, cy)
        c.drawRect(RectF(cx - halfW, cy - halfH, cx + halfW, cy + halfH), frame)
        c.drawText(text, cx, cy + 16f, paint)
        c.restore()
    }

    /** Pieni ilmeetön peruna kortin yläkulmaan. */
    private fun drawPotato(c: Canvas, cx: Float, cy: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val body = RectF(cx - 80f, cy - 62f, cx + 80f, cy + 62f)
        p.style = Paint.Style.FILL
        p.color = POTATO
        c.drawOval(body, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = POTATO_DARK
        c.drawOval(body, p)

        // Silmät
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawOval(RectF(cx - 46f, cy - 26f, cx - 14f, cy + 12f), p)
        c.drawOval(RectF(cx + 14f, cy - 26f, cx + 46f, cy + 12f), p)
        p.color = INK
        c.drawCircle(cx - 26f, cy - 4f, 7f, p)
        c.drawCircle(cx + 34f, cy - 4f, 7f, p)

        // Kulmat ja suu
        p.style = Paint.Style.STROKE
        p.strokeWidth = 6f
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(cx - 48f, cy - 38f, cx - 12f, cy - 38f, p)
        c.drawLine(cx + 12f, cy - 38f, cx + 48f, cy - 38f, p)
        c.drawLine(cx - 24f, cy + 32f, cx + 24f, cy + 32f, p)

        // Solmio
        p.style = Paint.Style.FILL
        p.color = STAMP
        val tie = android.graphics.Path().apply {
            moveTo(cx - 12f, cy + 60f)
            lineTo(cx + 12f, cy + 60f)
            lineTo(cx + 18f, cy + 100f)
            lineTo(cx, cy + 112f)
            lineTo(cx - 18f, cy + 100f)
            close()
        }
        c.drawPath(tie, p)
    }
}
