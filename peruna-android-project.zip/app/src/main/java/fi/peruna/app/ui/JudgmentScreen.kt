package fi.peruna.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.data.Rarity
import fi.peruna.app.sharing.ShareManager
import fi.peruna.app.ui.theme.PerunaColors

@Composable
fun JudgmentScreen(state: AppState) {
    val shown = state.shown
    if (shown == null) {
        LaunchedEffect(Unit) { state.goHome() }
        return
    }

    val context = LocalContext.current
    val scroll = rememberScrollState()
    val judgment = shown.judgment

    // Uusi tuomio alkaa aina sivun yläreunasta.
    LaunchedEffect(shown.judgment.id, shown.caseNumber) { scroll.scrollTo(0) }

    val mood = when {
        judgment.rarity != Rarity.COMMON -> Mood.SURPRISED
        judgment.category == "HYVÄKSYNTÄ" -> Mood.PLEASED
        judgment.category == "PERUNA" -> Mood.DISAPPOINTED
        else -> Mood.DEADPAN
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        RetroWindow(
            title = if (shown.isDaily) "PÄIVÄN_TUOMIO.DOC" else "TUOMIO.DOC",
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            onClose = { state.goHome() }
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scroll)
                    .padding(10.dp)
            ) {
                PaperPanel(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            MonoLabel("TAPAUS " + shown.caseNumber)
                            Spacer(Modifier.height(4.dp))
                            MonoLabel(
                                text = "LUOKKA: " + judgment.category,
                                color = PerunaColors.Olive
                            )
                        }
                        PerunaMascot(mood = mood, modifier = Modifier.size(64.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Rule()
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = judgment.headline,
                        color = PerunaColors.Ink,
                        fontSize = 22.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (judgment.body.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = judgment.body,
                            color = PerunaColors.Ink,
                            fontSize = 17.sp,
                            lineHeight = 24.sp
                        )
                    }
                    Spacer(Modifier.height(18.dp))
                    Rule()
                    Spacer(Modifier.height(8.dp))
                    MonoLabel(
                        text = "LUOTETTAVUUS: " + shown.reliability,
                        color = PerunaColors.Olive
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Stamp(text = shown.stamp, modifier = Modifier.padding(end = 6.dp, bottom = 4.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        RetroButton(
            text = "UUSI TUOMIO",
            onClick = { state.giveJudgment() },
            modifier = Modifier.fillMaxWidth(),
            kind = ButtonKind.Primary,
            fontSize = 20.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RetroButton(
                text = "JAA",
                onClick = {
                    ShareManager.shareText(context, ShareManager.buildText(shown))
                    state.recordShare()
                },
                modifier = Modifier.weight(1f),
                fontSize = 14.sp
            )
            RetroButton(
                text = "KORTTI",
                onClick = {
                    ShareManager.shareCard(context, shown)
                    state.recordShare()
                },
                modifier = Modifier.weight(1f),
                fontSize = 14.sp
            )
            RetroButton(
                text = "TAKAISIN",
                onClick = { state.goHome() },
                modifier = Modifier.weight(1f),
                fontSize = 14.sp
            )
        }
    }
}
