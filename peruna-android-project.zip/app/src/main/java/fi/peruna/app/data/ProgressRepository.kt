package fi.peruna.app.data

import android.content.Context

/**
 * Tallentaa edistymisen puhelimen omaan SharedPreferences-tiedostoon.
 * Ei verkkoa, ei tiliä, ei pilveä.
 */
class ProgressRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): AppProgress = AppProgress(
        judgmentCount = prefs.getInt(K_JUDGMENTS, 0),
        completedTaskCount = prefs.getInt(K_COMPLETED, 0),
        declinedTaskCount = prefs.getInt(K_DECLINED, 0),
        shareCount = prefs.getInt(K_SHARES, 0),
        unlockedAchievementIds = readList(K_UNLOCKED).toSet(),
        recentJudgmentIds = readList(K_RECENT_J),
        recentTaskIds = readList(K_RECENT_T),
        secretFlags = readList(K_FLAGS).toSet(),
        categoriesSeen = readList(K_CATEGORIES).toSet(),
        daysUsed = readList(K_DAYS).mapNotNull { it.toLongOrNull() }.toSet(),
        lastDailyDay = prefs.getLong(K_LAST_DAILY, -1L)
    )

    fun save(p: AppProgress) {
        prefs.edit()
            .putInt(K_JUDGMENTS, p.judgmentCount)
            .putInt(K_COMPLETED, p.completedTaskCount)
            .putInt(K_DECLINED, p.declinedTaskCount)
            .putInt(K_SHARES, p.shareCount)
            .putString(K_UNLOCKED, p.unlockedAchievementIds.joinToString(SEP))
            .putString(K_RECENT_J, p.recentJudgmentIds.joinToString(SEP))
            .putString(K_RECENT_T, p.recentTaskIds.joinToString(SEP))
            .putString(K_FLAGS, p.secretFlags.joinToString(SEP))
            .putString(K_CATEGORIES, p.categoriesSeen.joinToString(SEP))
            .putString(K_DAYS, p.daysUsed.joinToString(SEP))
            .putLong(K_LAST_DAILY, p.lastDailyDay)
            .commit() // commit(): tallennus on varmasti levyllä, vaikka sovellus suljettaisiin heti
    }

    fun reset() {
        prefs.edit().clear().commit()
    }

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "")
            .split(SEP)
            .filter { it.isNotBlank() }

    private companion object {
        const val PREFS_NAME = "peruna_progress"
        const val SEP = ","

        const val K_JUDGMENTS = "judgment_count"
        const val K_COMPLETED = "completed_tasks"
        const val K_DECLINED = "declined_tasks"
        const val K_SHARES = "share_count"
        const val K_UNLOCKED = "unlocked"
        const val K_RECENT_J = "recent_judgments"
        const val K_RECENT_T = "recent_tasks"
        const val K_FLAGS = "secret_flags"
        const val K_CATEGORIES = "categories_seen"
        const val K_DAYS = "days_used"
        const val K_LAST_DAILY = "last_daily_day"
    }
}
