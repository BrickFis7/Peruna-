package fi.peruna.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import fi.peruna.app.ui.theme.PerunaColors

enum class Mood { DEADPAN, PLEASED, DISAPPOINTED, SURPRISED }

/**
 * PERUNA-maskotti: ilmeetön peruna solmiossa. Piirretty kokonaan koodilla (ei kuvatiedostoja).
 * Piirtoalue on 200 x 200 yksikköä ja skaalataan komponentin kokoon.
 */
@Composable
fun PerunaMascot(mood: Mood, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val s = size.minDimension / 200f
        withTransform({ scale(scaleX = s, scaleY = s, pivot = Offset.Zero) }) {
            drawPotato(mood)
        }
    }
}

private fun DrawScope.drawPotato(mood: Mood) {
    val outline = PerunaColors.PotatoDark
    val ink = PerunaColors.Ink

    // Peruna
    val body = Path().apply {
        moveTo(100f, 14f)
        cubicTo(150f, 10f, 180f, 50f, 174f, 96f)
        cubicTo(170f, 134f, 142f, 160f, 100f, 160f)
        cubicTo(58f, 160f, 28f, 136f, 26f, 98f)
        cubicTo(24f, 50f, 52f, 18f, 100f, 14f)
        close()
    }
    drawPath(body, PerunaColors.Potato)
    drawPath(body, outline, style = Stroke(width = 4f))

    // Perunan "silmät" (läikät)
    val spot = outline.copy(alpha = 0.45f)
    drawCircle(spot, radius = 3.5f, center = Offset(56f, 56f))
    drawCircle(spot, radius = 3f, center = Offset(142f, 50f))
    drawCircle(spot, radius = 4f, center = Offset(152f, 120f))
    drawCircle(spot, radius = 3f, center = Offset(48f, 122f))
    drawCircle(spot, radius = 2.5f, center = Offset(110f, 34f))

    // Silmät
    val eyeSize = Size(26f, 30f)
    drawOval(Color.White, topLeft = Offset(63f, 73f), size = eyeSize)
    drawOval(Color.White, topLeft = Offset(111f, 73f), size = eyeSize)
    drawOval(ink, topLeft = Offset(63f, 73f), size = eyeSize, style = Stroke(width = 2f))
    drawOval(ink, topLeft = Offset(111f, 73f), size = eyeSize, style = Stroke(width = 2f))
    // Hieman nolo katse sivulle
    drawCircle(ink, radius = 5f, center = Offset(80f, 92f))
    drawCircle(ink, radius = 5f, center = Offset(128f, 92f))

    // Kulmat ja suu mielialan mukaan
    val brow = Stroke(width = 4f, cap = StrokeCap.Round)
    when (mood) {
        Mood.DEADPAN -> {
            drawLine(ink, Offset(62f, 66f), Offset(90f, 66f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(ink, Offset(110f, 66f), Offset(138f, 66f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(ink, Offset(82f, 127f), Offset(118f, 127f), strokeWidth = 4f, cap = StrokeCap.Round)
        }
        Mood.PLEASED -> {
            drawLine(ink, Offset(62f, 66f), Offset(90f, 62f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(ink, Offset(110f, 62f), Offset(138f, 66f), strokeWidth = 4f, cap = StrokeCap.Round)
            val smile = Path().apply {
                moveTo(80f, 122f)
                cubicTo(90f, 136f, 110f, 136f, 120f, 122f)
            }
            drawPath(smile, ink, style = brow)
        }
        Mood.DISAPPOINTED -> {
            drawLine(ink, Offset(62f, 71f), Offset(90f, 62f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(ink, Offset(110f, 62f), Offset(138f, 71f), strokeWidth = 4f, cap = StrokeCap.Round)
            val frown = Path().apply {
                moveTo(80f, 133f)
                cubicTo(90f, 120f, 110f, 120f, 120f, 133f)
            }
            drawPath(frown, ink, style = brow)
        }
        Mood.SURPRISED -> {
            drawLine(ink, Offset(62f, 58f), Offset(90f, 55f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(ink, Offset(110f, 55f), Offset(138f, 58f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawCircle(ink, radius = 8f, center = Offset(100f, 128f), style = Stroke(width = 4f))
        }
    }

    // Kaulus
    val collarLeft = Path().apply {
        moveTo(100f, 152f); lineTo(70f, 148f); lineTo(84f, 174f); close()
    }
    val collarRight = Path().apply {
        moveTo(100f, 152f); lineTo(130f, 148f); lineTo(116f, 174f); close()
    }
    drawPath(collarLeft, PerunaColors.Paper)
    drawPath(collarLeft, ink, style = Stroke(width = 2f))
    drawPath(collarRight, PerunaColors.Paper)
    drawPath(collarRight, ink, style = Stroke(width = 2f))

    // Solmio
    val knot = Path().apply {
        moveTo(92f, 152f); lineTo(108f, 152f); lineTo(105f, 165f); lineTo(95f, 165f); close()
    }
    val tie = Path().apply {
        moveTo(95f, 165f); lineTo(105f, 165f); lineTo(113f, 190f); lineTo(100f, 198f); lineTo(87f, 190f); close()
    }
    drawPath(tie, PerunaColors.Stamp)
    drawPath(tie, ink, style = Stroke(width = 2f))
    drawPath(knot, PerunaColors.Stamp)
    drawPath(knot, ink, style = Stroke(width = 2f))
}
