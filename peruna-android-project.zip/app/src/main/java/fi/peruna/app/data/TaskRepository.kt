package fi.peruna.app.data

import kotlin.random.Random

object TaskRepository {

    const val RECENT_LIMIT = 15

    val all: List<PerunaTask> = Content.tasks

    fun draw(progress: AppProgress, random: Random): PerunaTask {
        val recent = progress.recentTaskIds.take(RECENT_LIMIT).toSet()
        var candidates = all.filter { it.id !in recent }
        if (candidates.isEmpty()) candidates = all
        return candidates[random.nextInt(candidates.size)]
    }
}
