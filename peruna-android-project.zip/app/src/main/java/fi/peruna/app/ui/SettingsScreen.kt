package fi.peruna.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.BuildConfig
import fi.peruna.app.data.Achievements
import fi.peruna.app.ui.theme.PerunaColors

@Composable
fun SettingsScreen(state: AppState) {
    var confirmReset by remember { mutableStateOf(false) }
    var resetDone by remember { mutableStateOf(false) }
    val p = state.progress

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        RetroWindow(
            title = "ASETUKSET / TIETOA",
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            onClose = { state.goHome() }
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(10.dp)
            ) {
                PaperPanel(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("VERSIO")
                    BodyText("PERUNA™ OS v" + BuildConfig.VERSION_NAME + " (koontiversio " + BuildConfig.VERSION_CODE + ")")
                    Spacer(Modifier.height(4.dp))
                    BodyText("Virallista hölynpölyä vuodesta 1998.")

                    Spacer(Modifier.height(16.dp))
                    SectionTitle("TILASTOT")
                    BodyText("Tuomioita annettu: " + p.judgmentCount)
                    BodyText("Tehtäviä tehty: " + p.completedTaskCount)
                    BodyText("Tehtäviä tunnustamatta: " + p.declinedTaskCount)
                    BodyText("Tuomioita jaettu: " + p.shareCount)
                    BodyText(
                        "Saavutuksia avattu: " + p.unlockedAchievementIds.size +
                            " / " + Achievements.all.size
                    )

                    Spacer(Modifier.height(16.dp))
                    SectionTitle("VASTUUVAPAUSLAUSEKE")
                    BodyText(
                        "PERUNA™ on kuvitteellinen. Kaikki tuomiot, tehtävät ja saavutukset " +
                            "ovat humoristista fiktiota, eikä niillä ole virallista asemaa. " +
                            "PERUNA ei ole viranomainen, lääkäri, juristi eikä oikea peruna. " +
                            "Älä tee elämänmuutoksia perunan tuomioiden perusteella."
                    )
                    Spacer(Modifier.height(8.dp))
                    BodyText(
                        "Kaikki tehtävät ovat vapaaehtoisia, vaarattomia ja ilmaisia. " +
                            "Tuomiot on tarkoitettu naurettaviksi, ei uskottaviksi."
                    )

                    Spacer(Modifier.height(16.dp))
                    SectionTitle("TIETOSUOJA")
                    BodyText(
                        "Sovellus toimii kokonaan ilman verkkoyhteyttä: ei tiliä, ei mainoksia, " +
                            "ei seurantaa. Puhelimeen tallentuu vain se, mitä tarvitaan saavutusten " +
                            "ja viimeisimpien tuomioiden muistamiseen. Tiedot pysyvät tällä laitteella."
                    )
                    Spacer(Modifier.height(4.dp))
                    BodyText("PERUNA OS is fictional. For entertainment only.")
                }

                Spacer(Modifier.height(14.dp))
                RetroButton(
                    text = "NOLLAA EDISTYMINEN",
                    onClick = { confirmReset = true },
                    modifier = Modifier.fillMaxWidth(),
                    kind = ButtonKind.Danger,
                    fontSize = 15.sp
                )
                if (resetDone) {
                    Spacer(Modifier.height(10.dp))
                    MonoLabel(
                        text = "Edistyminen nollattu. PERUNA ei muista mitään. Tämä on sen vahvuus.",
                        color = PerunaColors.Olive
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        RetroButton(
            text = "TAKAISIN",
            onClick = { state.goHome() },
            modifier = Modifier.fillMaxWidth(),
            fontSize = 14.sp
        )
    }

    if (confirmReset) {
        RetroDialog(
            title = "VAHVISTA NOLLAUS",
            message = "Tuomiohistoria, tehtävät, tilastot ja saavutukset poistetaan tästä puhelimesta. " +
                "Toimintoa ei voi perua, vaikka PERUNA haluaisi.",
            confirmText = "NOLLAA",
            onConfirm = {
                state.resetProgress()
                confirmReset = false
                resetDone = true
            },
            onDismiss = { confirmReset = false },
            dismissText = "PERUUTA",
            danger = true
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    MonoLabel(text = text, color = PerunaColors.Olive, fontSize = 14.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun BodyText(text: String) {
    Text(
        text = text,
        color = PerunaColors.Ink,
        fontSize = 15.sp,
        lineHeight = 21.sp
    )
}
