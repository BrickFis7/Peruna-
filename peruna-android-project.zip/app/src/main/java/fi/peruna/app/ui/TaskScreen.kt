package fi.peruna.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.ui.theme.PerunaColors

@Composable
fun TaskScreen(state: AppState) {
    val task = state.currentTask
    if (task == null) {
        LaunchedEffect(Unit) { state.goHome() }
        return
    }
    val answer = state.taskAnswer
    val scroll = rememberScrollState()

    LaunchedEffect(task.id) { scroll.scrollTo(0) }

    val mood = when {
        answer == null -> Mood.DEADPAN
        answer.completed -> Mood.PLEASED
        else -> Mood.DISAPPOINTED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        RetroWindow(
            title = "TEHTÄVÄ.EXE",
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            onClose = { state.goHome() }
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scroll)
                    .padding(10.dp)
            ) {
                PaperPanel(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            MonoLabel("TEHTÄVÄ NRO " + task.id.removePrefix("T"))
                            Spacer(Modifier.height(4.dp))
                            MonoLabel(
                                text = "TILA: " + (if (answer == null) "ODOTTAA" else "KÄSITELTY"),
                                color = PerunaColors.Olive
                            )
                        }
                        PerunaMascot(mood = mood, modifier = Modifier.size(64.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Rule()
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = task.prompt,
                        color = PerunaColors.Ink,
                        fontSize = 22.sp,
                        lineHeight = 29.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (answer == null) {
                        Spacer(Modifier.height(16.dp))
                        MonoLabel(
                            text = "Tehtävä on vapaaehtoinen, harmiton eikä vaadi ostoksia.",
                            fontSize = 12.sp,
                            bold = false
                        )
                    } else {
                        Spacer(Modifier.height(18.dp))
                        Rule()
                        Spacer(Modifier.height(8.dp))
                        MonoLabel(text = "KIRJAUS:", color = PerunaColors.Olive)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = answer.response,
                            color = PerunaColors.Ink,
                            fontSize = 17.sp,
                            lineHeight = 24.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Stamp(
                                text = if (answer.completed) "SUORITETTU" else "EI TUNNUSTETTU",
                                modifier = Modifier.padding(end = 6.dp, bottom = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (answer == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RetroButton(
                    text = "TEHTY",
                    onClick = { state.answerTask(completed = true) },
                    modifier = Modifier.weight(1f),
                    kind = ButtonKind.Primary,
                    fontSize = 18.sp
                )
                RetroButton(
                    text = "EN TUNNUSTA",
                    onClick = { state.answerTask(completed = false) },
                    modifier = Modifier.weight(1f),
                    fontSize = 15.sp
                )
            }
        } else {
            RetroButton(
                text = "SEURAAVA TEHTÄVÄ",
                onClick = { state.giveTask() },
                modifier = Modifier.fillMaxWidth(),
                kind = ButtonKind.Primary,
                fontSize = 18.sp
            )
        }
        Spacer(Modifier.height(8.dp))
        RetroButton(
            text = "TAKAISIN",
            onClick = { state.goHome() },
            modifier = Modifier.fillMaxWidth(),
            fontSize = 14.sp
        )
    }
}
