package fi.peruna.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.remember
import fi.peruna.app.data.ProgressRepository
import fi.peruna.app.ui.AppState
import fi.peruna.app.ui.PerunaApp
import fi.peruna.app.ui.Screen
import fi.peruna.app.ui.theme.PerunaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PerunaTheme {
                val state = remember { AppState(ProgressRepository(applicationContext)) }
                // Takaisin-nappi vie etusivulle; etusivulta se sulkee sovelluksen.
                BackHandler(enabled = state.screen != Screen.HOME) { state.goHome() }
                PerunaApp(state)
            }
        }
    }
}
