package fi.peruna.app.data

/** Kuinka harvinainen tuomio on. SECRET-tuomiot tulevat vain erikoistapahtumina. */
enum class Rarity { COMMON, RARE, SECRET }

/** Luokat, jotka kuuluvat tavalliseen tuomioiden valikoimaan. */
object Categories {
    val normal: List<String> = listOf(
        "ARKI",
        "BYROKRATIA",
        "ENNUSTE",
        "HAVAINTO",
        "MÄÄRÄYS",
        "HYVÄKSYNTÄ",
        "TILINTARKASTUS",
        "PERUNA"
    )
}

data class Judgment(
    val id: String,
    val category: String,
    val headline: String,
    val body: String,
    val rarity: Rarity = Rarity.COMMON
)

data class PerunaTask(
    val id: String,
    val prompt: String,
    val completedResponse: String,
    val declinedResponse: String
)

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    /** Absurdi vihje, joka näytetään lukitulle saavutukselle. */
    val hint: String,
    /** Salaisen saavutuksen nimi piilotetaan, kunnes se on avattu. */
    val secret: Boolean,
    val unlockRule: (AppProgress) -> Boolean
)

/** Kaikki paikallisesti tallennettu tila. Ei henkilötietoja. */
data class AppProgress(
    val judgmentCount: Int = 0,
    val completedTaskCount: Int = 0,
    val declinedTaskCount: Int = 0,
    val shareCount: Int = 0,
    val unlockedAchievementIds: Set<String> = emptySet(),
    /** Uusin ensin. */
    val recentJudgmentIds: List<String> = emptyList(),
    /** Uusin ensin. */
    val recentTaskIds: List<String> = emptyList(),
    val secretFlags: Set<String> = emptySet(),
    val categoriesSeen: Set<String> = emptySet(),
    /** Päivät (epoch day), joina sovellusta on käytetty. */
    val daysUsed: Set<Long> = emptySet(),
    /** Päivä, jolle päivän tuomio on jo laskettu mukaan tilastoihin. */
    val lastDailyDay: Long = -1L
)

/** Näytettävä tuomio kaikkine koristeineen (asiakirjanumero, leima, luotettavuus). */
data class ShownJudgment(
    val judgment: Judgment,
    val caseNumber: String,
    val reliability: String,
    val stamp: String,
    val isDaily: Boolean
)

data class TaskAnswer(
    val completed: Boolean,
    val response: String
)
