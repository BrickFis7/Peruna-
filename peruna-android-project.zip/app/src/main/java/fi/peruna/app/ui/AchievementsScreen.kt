package fi.peruna.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.data.Achievement
import fi.peruna.app.data.Achievements
import fi.peruna.app.ui.theme.PerunaColors

@Composable
fun AchievementsScreen(state: AppState) {
    val unlocked = state.progress.unlockedAchievementIds

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        RetroWindow(
            title = "SAAVUTUKSET.LOG",
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            onClose = { state.goHome() }
        ) {
            MonoLabel(
                text = "AVATTU " + unlocked.size + " / " + Achievements.all.size,
                color = PerunaColors.Olive,
                fontSize = 15.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
            )
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                items(Achievements.all, key = { it.id }) { achievement ->
                    AchievementRow(achievement, achievement.id in unlocked)
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        RetroButton(
            text = "TAKAISIN",
            onClick = { state.goHome() },
            modifier = Modifier.fillMaxWidth(),
            fontSize = 14.sp
        )
    }
}

@Composable
private fun AchievementRow(achievement: Achievement, isUnlocked: Boolean) {
    val title = when {
        isUnlocked -> achievement.title
        achievement.secret -> "??? SALAINEN"
        else -> achievement.title
    }
    val detail = if (isUnlocked) achievement.description else "Ehto: " + achievement.hint

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isUnlocked) PerunaColors.Paper else PerunaColors.Chrome)
            .bevel(raised = !isUnlocked, thickness = 2.dp)
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = if (isUnlocked) "[X]" else "[ ]",
            color = if (isUnlocked) PerunaColors.Olive else PerunaColors.InkSoft,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 10.dp)
        ) {
            Text(
                text = title,
                color = if (isUnlocked) PerunaColors.Ink else PerunaColors.InkSoft,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                lineHeight = 19.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = detail,
                color = if (isUnlocked) PerunaColors.Ink else PerunaColors.InkSoft,
                fontSize = 15.sp,
                lineHeight = 20.sp
            )
        }
    }
}
