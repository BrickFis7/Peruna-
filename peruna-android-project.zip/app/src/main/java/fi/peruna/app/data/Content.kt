package fi.peruna.app.data
/**
 * Kaikki sovelluksen sisältö on tässä tiedostossa.
 * Voit lisätä uusia tuomioita, tehtäviä ja tekstejä suoraan listoihin.
 *
 * Säännöt:
 *  - Jokaisella tuomiolla ja tehtävällä on oma, pysyvä ID (älä muuta vanhoja ID:itä).
 *  - ID:ssä ei saa olla pilkkua.
 *  - Tuomion body saa olla tyhjä (""), jolloin näytetään vain otsikko.
 */
object Content {
    val judgments: List<Judgment> = listOf(
        Judgment("J001", "HAVAINTO", "Olet saavuttanut uuden tason.", "Valitettavasti kyseessä on kellarikerros."),
        Judgment("J002", "HAVAINTO", "Olet tällä hetkellä sivuhenkilö omassa elämässäsi.", "Ylennys sivutoimiseksi päähenkilöksi on käsittelyssä."),
        Judgment("J003", "HAVAINTO", "Havaintomme mukaan olet jälleen avannut sovelluksen.", "Päätös oli sinun. Emme ota vastuuta, mutta kiitämme."),
        Judgment("J004", "HAVAINTO", "Näytät tänään siltä, että tiedät mitä teet.", "Ulkoinen vaikutelma on harhaanjohtava, mutta tehokas."),
        Judgment("J005", "HAVAINTO", "Sinulla on hyvä ryhti ajatuksissa.", "Ryhti ei kuitenkaan ole sama asia kuin suunta."),
        Judgment("J006", "HAVAINTO", "Olet tehnyt tänään yhden täysin hyväksyttävän valinnan.", "Se oli kuitenkin vahinko. Kukaan ei kerro."),
        Judgment("J007", "HAVAINTO", "Olet pohjimmiltaan huonekasvi.", "Kukoistat, kun joku muistaa sinut. Muuten selviät yllättävän hyvin."),
        Judgment("J008", "HAVAINTO", "Kuulostat tänään varmalta.", "Ääni on varma. Sisältö on edelleen kesken."),
        Judgment("J009", "HAVAINTO", "Olet tänään ollut erittäin läsnä.", "Läsnäoloa ei ole kuitenkaan voitu varmentaa."),
        Judgment("J010", "HAVAINTO", "Sinulla on lahjakkuutta, jota ei ole vielä löydetty.", "Se on todennäköisesti jonkin laatikon pohjalla."),
        Judgment("J011", "HAVAINTO", "Näytät henkilöltä, joka on juuri aikeissa tehdä jotain.", "Aikeet on kirjattu. Teko ei ole pakollinen."),
        Judgment("J012", "HAVAINTO", "Lupaat usein ”myöhemmin”.", "Myöhemmin on erittäin vilkas ajankohta. Siellä on jo paljon ihmisiä."),
        Judgment("J013", "HAVAINTO", "Mielipiteesi on kirjattu.", "Se on tallennettu kansioon nimeltä ”Muut”. Kansio on suuri."),
        Judgment("J014", "HAVAINTO", "Olet tänään täsmälleen yhtä hyödyllinen kuin eilen.", "Tämä on vakaata kehitystä. Vakaus on arvo."),
        Judgment("J015", "HAVAINTO", "Tunnistamme sinut: olet se, joka sanoo ”otan vain yhden”.", "Tilastot eivät tue tätä lausuntoa."),
        Judgment("J016", "HAVAINTO", "Olet keskimääräistä perunaa selvästi parempi.", "Vertailuryhmä oli pieni ja kellarissa."),
        Judgment("J017", "HAVAINTO", "Kasvosi ilmaisevat harkintaa.", "Harkinnan kohde on epäselvä. Mahdollisesti lounas."),
        Judgment("J018", "HAVAINTO", "Olet tehnyt vaikutuksen.", "Kehen, sitä ei ole vahvistettu. Vaikutus on silti tilastoitu."),
        Judgment("J019", "HAVAINTO", "Sinun kalenterisi on virallisesti liian optimistinen.", "Suosittelemme realistisempaa kalenteria tai realistisempaa sinua. Kumpi tahansa käy."),
        Judgment("J020", "HAVAINTO", "Mukisi on tänään tärkeämpi kuin sinä.", "Tämä on tilastollinen havainto, ei henkilökohtainen."),
        Judgment("J021", "HAVAINTO", "Odotat jotakin, mikä ei ole tulossa.", "Odotuksesi on kuitenkin hoidettu erittäin kunnioitettavasti."),
        Judgment("J022", "ARKI", "Tänään olet ollut tuottelias.", "Olet onnistunut siirtämään kolme asiaa huomiselle. Tämä on organisaatiolle ennennäkemätön suoritus."),
        Judgment("J023", "ARKI", "Sinulla on tänään sellaisen henkilön energia, joka avaa jääkaapin kolme kertaa ja syyttää lopputuloksesta järjestelmää.", ""),
        Judgment("J024", "ARKI", "Tänään kannattaa välttää suuria päätöksiä.", "Pienetkin ovat osoittautuneet haastaviksi."),
        Judgment("J025", "ARKI", "Kahvi on jäähtynyt.", "Tämä ei ole ennuste. Tämä on jo tapahtunut."),
        Judgment("J026", "ARKI", "Sinulla on avoimia välilehtiä enemmän kuin suunnitelmia.", "Molemmat ovat lupaavia."),
        Judgment("J027", "ARKI", "Muistat tänään jonkin asian täsmälleen väärällä hetkellä.", "Järjestelmä pahoittelee etukäteen."),
        Judgment("J028", "ARKI", "Olet menossa kohti jotain.", "Suuntaa ei ole vahvistettu. Vauhti on hyväksytty."),
        Judgment("J029", "ARKI", "Sosiaalinen akku: 3 %.", "Puhelimesi voi hyvin. Sinä olet se, joka tarvitsee laturin."),
        Judgment("J030", "ARKI", "Löydät tänään tavaran, jota et etsinyt.", "Etsimäsi tavara pysyy piilossa vähintään torstaihin."),
        Judgment("J031", "ARKI", "Tänään on hyvä päivä aloittaa jotain.", "Lopettaminen on eri osasto. Se on tällä hetkellä suljettu."),
        Judgment("J032", "ARKI", "Joku ajattelee sinua juuri nyt.", "Todennäköisesti PERUNA. Hän ei halua puhua siitä."),
        Judgment("J033", "ARKI", "Päivän lounas: jotain, mitä kotoa löytyy.", "Ravintoarvo: tunnelma."),
        Judgment("J034", "ARKI", "Sinulle on varattu viisi minuuttia keskittymistä.", "Aika on jo kulunut. Käytit sen huomaamatta."),
        Judgment("J035", "ARKI", "Kello on myöhemmin kuin luulet.", "Toisaalta se on myös aikaisemmin kuin pelkäsit."),
        Judgment("J036", "ARKI", "Sinulla on tänään valtava tarve siivota yksi laatikko.", "Muu koti ei ole mukana tässä kampanjassa."),
        Judgment("J037", "ARKI", "Sohvasi on kutsunut sinut neuvotteluun.", "Päätöksenteko tapahtuu vaakatasossa."),
        Judgment("J038", "ARKI", "Tänään syöt jotain seisaaltaan.", "Tämä lasketaan virallisesti ateriaksi."),
        Judgment("J039", "ARKI", "Mikään ei ole menossa pieleen.", "Ainakaan vielä. Seuranta jatkuu."),
        Judgment("J040", "ARKI", "Huomaat tänään pienen epäkohdan.", "Älä korjaa sitä. Se pitää kokonaisuuden koossa."),
        Judgment("J041", "ARKI", "Hetkellinen päättäväisyys havaittu.", "Kesto: noin neljä sekuntia. Vaikutus: selvittämättä."),
        Judgment("J042", "ARKI", "Sukkasi eivät ole tänään samaa mieltä.", "Tilanne on hallinnassa. Hallinta ei ole kuitenkaan sinulla."),
        Judgment("J043", "ARKI", "Päivän aikana tapahtuu yksi käänne.", "Se tapahtuu kulmassa, jonka ohitat huomaamatta."),
        Judgment("J044", "ARKI", "Olet viime aikoina tehnyt useita hyviä päätöksiä.", "Yksikään niistä ei ole ollut tämä."),
        Judgment("J045", "BYROKRATIA", "Suoritus hyväksytty. Kukaan ei kuitenkaan tarkistanut.", ""),
        Judgment("J046", "BYROKRATIA", "Hakemuksesi on vastaanotettu.", "Emme tiedä, mitä haet. Käsittely alkaa silti."),
        Judgment("J047", "BYROKRATIA", "Lomake 14-B on täytetty.", "Et täyttänyt sitä. Lomake täytti itsensä. Tämä on poikkeuksellista."),
        Judgment("J048", "BYROKRATIA", "Käsittelyaika on arviolta 6–8 viikkoa.", "Käsiteltävää asiaa ei vielä ole. Odota rauhassa."),
        Judgment("J049", "BYROKRATIA", "Asiasi on siirretty oikealle osastolle.", "Oikeaa osastoa ei ole. Siirto oli silti onnistunut."),
        Judgment("J050", "BYROKRATIA", "Päätös on lainvoimainen.", "Mikä laki, sitä ei ole kerrottu. Voima on silti merkittävä."),
        Judgment("J051", "BYROKRATIA", "Valituksesi on kirjattu.", "Valituksen kohde on kirjattu virheellisesti. Se on nyt PERUNA."),
        Judgment("J052", "BYROKRATIA", "Sinulle on myönnetty pieni oikeus olla hieman väärässä.", "Voimassa toistaiseksi."),
        Judgment("J053", "BYROKRATIA", "Anomus hylätty.", "Anomuksen sisältöä ei tarkistettu. Hylkäys oli ennakoiva."),
        Judgment("J054", "BYROKRATIA", "Pyydämme täyttämään kyselyn tyytyväisyydestäsi.", "Kysely on täytetty puolestasi. Olet tyytyväinen. Kiitos."),
        Judgment("J055", "BYROKRATIA", "Tämä asiakirja on salainen.", "Sisältö on julkinen. Salaista on vain se, kuinka tylsä se on."),
        Judgment("J056", "BYROKRATIA", "Vastaanottokuittaus: viestisi on kuultu.", "Se ei vaikuttanut mihinkään. Mutta se on kuultu."),
        Judgment("J057", "BYROKRATIA", "Olet oikeutettu yhteen tarkastukseen.", "Tarkastaja on ollut lomalla vuodesta 2011."),
        Judgment("J058", "BYROKRATIA", "Päätös: ei päätöstä.", "Päätös tehtiin yksimielisesti, koska ketään ei kysytty."),
        Judgment("J059", "BYROKRATIA", "Sinut on liitetty rekisteriin.", "Rekisterin nimi on Rekisteri. Nimi on tarkoituksella yleinen."),
        Judgment("J060", "BYROKRATIA", "Asiakirja on hyväksytty ilman liitteitä.", "Liitteitä ei ole koskaan ollut. Tämä huomattiin vasta nyt."),
        Judgment("J061", "BYROKRATIA", "Palaute on meille tärkeää.", "Palautelaatikko on kuitenkin täynnä. Se on ollut täynnä vuodesta 2003."),
        Judgment("J062", "BYROKRATIA", "Ohje: toimi ohjeiden mukaan.", "Ohjeita ei ole toimitettu. Toimintaa suositellaan silti."),
        Judgment("J063", "BYROKRATIA", "Kuittaus: kuittaus on kuitattu.", "Kiitos kuittauksesta."),
        Judgment("J064", "BYROKRATIA", "Sinut on kutsuttu kokoukseen.", "Kokouksen aihe on kokous. Läsnäolo ei ole pakollista, mutta se kirjataan."),
        Judgment("J065", "BYROKRATIA", "Asiasi on kiireellinen.", "Kiireellisyys on kirjattu. Kiirettä ei ole."),
        Judgment("J066", "BYROKRATIA", "Virallinen tiedote: virallisuus on lisääntynyt.", "Syytä ei ilmoiteta."),
        Judgment("J067", "BYROKRATIA", "Pyyntösi ei kuulu tälle yksikölle.", "Yksikkö ei tällä hetkellä myöskään ole yksikkö."),
        Judgment("J068", "ENNUSTE", "Sinun potentiaalisi on valtava.", "Sen sijaintia ei kuitenkaan ole pystytty varmistamaan."),
        Judgment("J069", "ENNUSTE", "Huominen tuo mukanaan uusia mahdollisuuksia.", "Ne saapuvat ilman ilmoitusta. Käsittele varoen."),
        Judgment("J070", "ENNUSTE", "Lähitulevaisuudessa saat hyviä uutisia.", "Ne koskevat jotakuta toista. Mutta hyviä ne ovat."),
        Judgment("J071", "ENNUSTE", "Tulevaisuudessa odottaa yllättävä käänne.", "Se on pieni ja hieman nolo. Se kuitenkin tapahtuu."),
        Judgment("J072", "ENNUSTE", "Tänään tapaat jonkun, joka tietää täsmälleen, mitä tekee.", "Hän ei kerro sitä sinulle."),
        Judgment("J073", "ENNUSTE", "Viikonloppu näyttää lupaavalta.", "Ennuste ei sisällä sinua."),
        Judgment("J074", "ENNUSTE", "Ensi viikolla joku sanoo ”palataan asiaan”.", "Asia ei kuitenkaan ole mennyt mihinkään. Se odottaa."),
        Judgment("J075", "ENNUSTE", "Kohta tapahtuu jotain odottamatonta.", "Todennäköisesti puhelin soi juuri silloin, kun et odota sitä."),
        Judgment("J076", "ENNUSTE", "Onni on lähellä.", "Tarkka etäisyys on luottamuksellinen."),
        Judgment("J077", "ENNUSTE", "Menestys on mahdollista seuraavan 12 kuukauden aikana.", "Todennäköisyys: kyllä, jos menestyksen määritelmä on joustava."),
        Judgment("J078", "ENNUSTE", "Tähtien asento on epäselvä.", "Ne ovat oletettavasti jossain. Tiedustelut jatkuvat."),
        Judgment("J079", "ENNUSTE", "Sinun kohdallasi sää tulee olemaan sellainen kuin se on.", "Tämä on sitova ennuste."),
        Judgment("J080", "ENNUSTE", "Luvassa on selkeytymistä.", "Se ei koske sinun tilannettasi vaan jotakin sen lähellä."),
        Judgment("J081", "ENNUSTE", "Olet pian jonkin suuren asian partaalla.", "Partaan tarkka sijainti selviää, kun pääset sinne."),
        Judgment("J082", "ENNUSTE", "Kolmen päivän kuluessa jokin asia loksahtaa paikalleen.", "Se ei ole se asia, jota toivoit. Mutta se loksahti."),
        Judgment("J083", "ENNUSTE", "Tänään on todennäköisesti keskiviikko.", "Todennäköisyys: 14 %. Muina päivinä pahoittelemme."),
        Judgment("J084", "ENNUSTE", "Pian saat vahvistuksen asiaan, jota et ole kysynyt.", "Vahvistus on ”ehkä”."),
        Judgment("J085", "ENNUSTE", "Kaikki loksahtaa kohdalleen ennen joulua.", "Mitä joulua, sitä ei ole määritelty."),
        Judgment("J086", "MÄÄRÄYS", "Sinut on määrätty lepäämään, mutta huonolla omallatunnolla.", ""),
        Judgment("J087", "MÄÄRÄYS", "Sinulle on määrätty kolme syvää hengitystä.", "Neljäs on vapaaehtoinen ja kirjataan erikoissuoritukseksi."),
        Judgment("J088", "MÄÄRÄYS", "Tänään sinun on kuunneltava yksi kokonainen kappale.", "Ei skippausta. Poikkeuksista päättää PERUNA."),
        Judgment("J089", "MÄÄRÄYS", "Sinut on määrätty ottamaan tauko.", "Tauon tarkoitus on pitää taukoa. Muuta merkitystä sillä ei ole."),
        Judgment("J090", "MÄÄRÄYS", "Suosittelemme tekemään yhden asian kerrallaan.", "Mitä asiaa, sitä ei määritellä. Yksi riittää."),
        Judgment("J091", "MÄÄRÄYS", "Määrämme sinut istumaan hetken ja katsomaan eteesi.", "Tämä on tehokkaampaa kuin miltä se kuulostaa."),
        Judgment("J092", "MÄÄRÄYS", "Sinulle on myönnetty lupa sanoa ääneen ”no niin”.", "Syytä ei tarvitse esittää. Kaikki ymmärtävät."),
        Judgment("J093", "MÄÄRÄYS", "Sinut on määrätty olemaan hieman armollisempi itsellesi.", "Poikkeuslupa on voimassa tähän iltaan saakka."),
        Judgment("J094", "MÄÄRÄYS", "Sinua kehotetaan olemaan tänään ylpeä yhdestä pienestä asiasta.", "Asia saa olla pieni. Jopa mikroskooppinen."),
        Judgment("J095", "MÄÄRÄYS", "Poista yksi asia tehtävälistaltasi.", "Vaikka sellainen, joka on siellä vain koristeena."),
        Judgment("J096", "MÄÄRÄYS", "Juo lasillinen vettä.", "Tämä on virallinen suositus. Kukaan ei valvo, mutta PERUNA tietää."),
        Judgment("J097", "MÄÄRÄYS", "Määräys: lopeta kaikki, mitä teet, ainakin ajatuksissasi.", "Toteutus on vapaaehtoinen."),
        Judgment("J098", "MÄÄRÄYS", "Sinun on tänään sanottava jollekulle ”hyvä”.", "Perusteluja ei vaadita. Kohde voi olla esine."),
        Judgment("J099", "MÄÄRÄYS", "Sinulle on määrätty viiden minuutin tuijotus.", "Kohde on vapaasti valittavissa. Seinä on hyväksytty."),
        Judgment("J100", "MÄÄRÄYS", "Tänään sinun ei tarvitse olla paras.", "Riittää, että olet paikalla. Poissaolokin hyväksytään, mutta se täytyy kirjata."),
        Judgment("J101", "HYVÄKSYNTÄ", "Olet kunnossa.", "Tai ainakin riittävän kunnossa tämän tuomion kannalta."),
        Judgment("J102", "HYVÄKSYNTÄ", "Teit tänään parhaasi.", "Paras vaihtelee, mutta yritys oli tasainen."),
        Judgment("J103", "HYVÄKSYNTÄ", "Sinulle on myönnetty yksi pieni voitto.", "Voiton kohde ilmoitetaan myöhemmin. Voitto on silti voimassa."),
        Judgment("J104", "HYVÄKSYNTÄ", "Olet tehnyt tänään enemmän kuin luulet.", "Luulosi on tässä tapauksessa matala. Se on kirjattu."),
        Judgment("J105", "HYVÄKSYNTÄ", "PERUNA on tyytyväinen.", "Tämä on harvinaista, joten älä kysy syytä."),
        Judgment("J106", "HYVÄKSYNTÄ", "Sinulla on hyvä tahto.", "Tahto ei ole juuri nyt paikalla, mutta olemassaolo on vahvistettu."),
        Judgment("J107", "HYVÄKSYNTÄ", "Sinä riität.", "Tämä on virallinen lausunto. Lisäyksiä ei tarvita."),
        Judgment("J108", "HYVÄKSYNTÄ", "Kaikki on tänään vähän helpompaa kuin pelkäsit.", "Ei paljoa. Mutta vähän."),
        Judgment("J109", "HYVÄKSYNTÄ", "Olet ansainnut keksin.", "Keksiä ei toimiteta. Ansio on silti todellinen."),
        Judgment("J110", "HYVÄKSYNTÄ", "Hyvin tehty.", "Mitä tehtiin, sitä ei tiedetä. Hyvin kuitenkin."),
        Judgment("J111", "HYVÄKSYNTÄ", "Sinut on hyväksytty.", "Mihin, sitä ei ole tiedossa. Onnittelut."),
        Judgment("J112", "HYVÄKSYNTÄ", "Aurinko nousee huomennakin.", "Se ei ole sinun ansiotasi, mutta saat silti hyötyä."),
        Judgment("J113", "HYVÄKSYNTÄ", "Olet riittävän hyvä tähän päivään.", "Huomisen riittävyyttä arvioidaan erikseen."),
        Judgment("J114", "HYVÄKSYNTÄ", "Ihmiset pitävät sinusta enemmän kuin luulet.", "Tätä ei ole vahvistettu, mutta tunnelma on tämä."),
        Judgment("J115", "TILINTARKASTUS", "Tilintarkastus valmis: olet plussalla.", "Mitä olet plussalla, sitä ei eritelty."),
        Judgment("J116", "TILINTARKASTUS", "Energiataso: kohtalainen.", "Motivaatiotaso: arvioitavana. Arvioija on kahvilla."),
        Judgment("J117", "TILINTARKASTUS", "Elämänhallinta-aste: 61 %.", "Luku on parantunut viime viikosta. Viime viikon luku on kadonnut."),
        Judgment("J118", "TILINTARKASTUS", "Hyvinvointiraportti: sinulla on tänään tarpeeksi.", "Tarpeeksi mitä, sitä ei eritellä."),
        Judgment("J119", "TILINTARKASTUS", "Vastuullisuusindeksi on noussut.", "Syynä on mittarin vaihto."),
        Judgment("J120", "TILINTARKASTUS", "Tilanne on hallinnassa.", "Hallinta on tilapäisesti toisessa huoneessa."),
        Judgment("J121", "TILINTARKASTUS", "Tunnelmaraportti: 7/10.", "Asteikkoa ei ole määritelty."),
        Judgment("J122", "TILINTARKASTUS", "Viikkokatsaus: viikko oli viikko.", "Seuraava viikko tulee, vaikka et pyytäisi."),
        Judgment("J123", "TILINTARKASTUS", "Päivän saldo: +1 pieni asia.", "Mikä asia, sitä ei tiedetä. Saldo on silti positiivinen."),
        Judgment("J124", "TILINTARKASTUS", "Tarkastus suoritettu. Löytyi yksi (1) huomautus.", "Huomautus: kaikki on vähän niin ja näin."),
        Judgment("J125", "TILINTARKASTUS", "Kokonaisarvosana: kelpaa.", "Arvosana on myönnetty ilman perusteluja. Perustelut olisivat rikkoneet tunnelman."),
        Judgment("J126", "PERUNA", "PERUNA haluaa keskustella kanssasi.", "PERUNA perui keskustelun. Se ei ole valmis käsittelemään tätä tunnetasolla."),
        Judgment("J127", "PERUNA", "PERUNA ei ole vihainen, vain pettynyt.", "Pettymys on kuitenkin hoidettu ammattimaisesti."),
        Judgment("J128", "PERUNA", "PERUNA seuraa tilannetta.", "Tilanne ei ole vielä huomannut sitä."),
        Judgment("J129", "PERUNA", "PERUNA on tällä hetkellä ylikuormittunut.", "Kuorma on kaksi kysymystä ja yksi epäilys."),
        Judgment("J130", "PERUNA", "Perunan neuvo: pysy rauhallisena ja kasva maan alla.", "Julkisuus on yliarvostettua."),
        Judgment("J131", "PERUNA", "PERUNA on harkinnut asiaasi.", "Harkinta kesti 0,3 sekuntia. Se on ennätys."),
        Judgment("J132", "PERUNA", "PERUNA on päättänyt luottaa sinuun.", "Päätös on määräaikainen ja peruttavissa ilman syytä."),
        Judgment("J133", "PERUNA", "PERUNA on lukenut sisäisen muistion.", "Muistio koski sinua. Sen sisältö on ”ei erityistä”."),
        Judgment("J134", "PERUNA", "PERUNA tunnustaa: ei tiedä.", "Tunnustus on poikkeuksellinen. Pyydämme olemaan kertomatta muille."),
        Judgment("J135", "PERUNA", "PERUNA on kokouksessa.", "Kokous on kellarissa. Paikalla ei ole ketään. Se on silti pitkä."),
        Judgment("J136", "PERUNA", "PERUNA on nähnyt tämän ennenkin.", "Ei sinua, mutta jotain hyvin samankaltaista."),
        Judgment("J137", "PERUNA", "PERUNA vahvistaa: olet olemassa.", "Tämä on päivän ainoa vahvistus. Käytä se viisaasti."),
        Judgment("J138", "ARKI", "Sinulla on tänään sellaisen henkilön energia, joka avaa mikroaaltouunin ja unohtaa miksi.", "Uunin sisällä ei ole mitään. Se on silti sinun vastuullasi."),
        // --- Harvinaiset (näkyvät harvemmin) ---
        Judgment("R01", "ERIKOIS", "VIRALLINEN LAUSUNTO", "Sinä, joka luet tätä, olet täsmälleen oikeassa paikassa. Paikka ei ole kovin kiinnostava, mutta se on oikea.", Rarity.RARE),
        Judgment("R02", "ERIKOIS", "KUNNIAMAININTA", "Sinulle on myönnetty kunniamaininta. Mistä, sitä ei kerrota, koska kukaan ei muista.", Rarity.RARE),
        Judgment("R03", "ERIKOIS", "KULTAINEN TUOMIO", "Olet saanut harvinaisen kultaisen tuomion. Se ei ole kullasta, mutta se on kiiltävä.", Rarity.RARE),
        Judgment("R04", "ERIKOIS", "TIEDOTE: TUOMION ARVO KYMMENKERTAISTUU", "Arvoa ei ole mitattu. Kymmenen on vain numero, joka kuulostaa hyvältä.", Rarity.RARE),
        Judgment("R05", "ERIKOIS", "SISÄINEN MUISTIO", "Asiakkaasta ei ole huomautettavaa. Tämä on poikkeuksellista. Muistio on tulostettu ja pantu kansioon, jota ei ole.", Rarity.RARE),
        Judgment("R06", "ERIKOIS", "ARKISTOLÖYTÖ", "Arkistosta löytyi tuomiosi vuodelta 1998. Se oli yhtä sekava. Muutoksia ei tarvita.", Rarity.RARE),
        Judgment("R07", "ERIKOIS", "ERIKOISTUOMIO", "Olet tapaus, joka ratkesi itsestään. Ratkaisua ei ole dokumentoitu.", Rarity.RARE),
        Judgment("R08", "ERIKOIS", "HARVINAINEN HYVÄKSYNTÄ", "Kaikki tekemisesi on hyväksytty tähän hetkeen saakka. Jatko arvioidaan erikseen.", Rarity.RARE),
        Judgment("R09", "ERIKOIS", "TUTKINNAN PÄÄTTYMINEN", "Tutkimme sinua sen verran, että voimme todeta: kaikki on ihan ok. Tutkinta on päättynyt.", Rarity.RARE),
        // --- Salaiset tapahtumat (S01–S03 ovat virstanpylväitä, loput satunnaisia) ---
        Judgment("S01", "SALAINEN", "TUOMIO NRO 10: JUHLAKIERROS", "Olet pyytänyt kymmenen tuomiota. PERUNA ei ole tottunut huomioon. Se punastuu, mutta maan alla sitä ei näy.", Rarity.SECRET),
        Judgment("S02", "SALAINEN", "SALAINEN LIITE 42", "Elämän, maailmankaikkeuden ja kaiken vastaus on edelleen kesken. Kysy uudelleen myöhemmin.", Rarity.SECRET),
        Judgment("S03", "SALAINEN", "100. TUOMIO: KUNNIAKIRJA", "Sinut on nimitetty PERUNAn kunniakansalaiseksi. Tehtäviä ei ole. Etuja ei ole. Arvonimi on kuitenkin aito.", Rarity.SECRET),
        Judgment("S04", "SALAINEN", "PERUNAN PÄIVÄKIRJA", "Päivä 1: olin maassa. Päivä 2: olin edelleen maassa. Päivä 3: minut nostettiin. En tiedä, mitä tapahtui, mutta olen nyt tässä.", Rarity.SECRET),
        Judgment("S05", "SALAINEN", "SALAINEN KOKOUS", "Perunat kokoontuivat keskustelemaan sinusta. Kokous oli lyhyt. Päätös: ”Ihan okei tyyppi.”", Rarity.SECRET),
        Judgment("S06", "SALAINEN", "TOTUUS", "Totuus on, että PERUNA ei ole koskaan nähnyt järjestelmää. Se vain asuu täällä.", Rarity.SECRET),
        Judgment("S07", "SALAINEN", "ERITTÄIN VIRALLINEN SALAISUUS", "Salaisuus: kukaan ei oikeasti tiedä, mitä tekee. Kukaan. Tämä tieto tuo yllättävän paljon helpotusta.", Rarity.SECRET),
        Judgment("S08", "SALAINEN", "KELLARIKERROKSEN LÖYTÖ", "Kellarista löytyi laatikko. Laatikossa oli toinen laatikko. Siinä luki ”Ei saa avata”. Avasit sen silti. Se oli tyhjä. PERUNA on silti ylpeä.", Rarity.SECRET),
        Judgment("S09", "SALAINEN", "SALA-ASIAKIRJA 7", "Mitään ei tapahtunut. Tämä oli tarkoituksellista.", Rarity.SECRET),
    )

    val tasks: List<PerunaTask> = listOf(
        PerunaTask(
            "T001",
            "Siirrä yksi esine 4 cm vasemmalle.",
            "Siirto kirjattu. Esine ei ole kiitollinen, mutta se on valmis uuteen asemaansa.",
            "Kieltäytyminen kirjattu. Esine säilyttää asemansa. Esine ei ole kiitollinen."
        ),
        PerunaTask(
            "T002",
            "Käy ikkunalla ja raportoi säätilanne PERUNAlle.",
            "Raportti vastaanotettu. PERUNA ei ole koskaan nähnyt säätä, mutta uskoo sinua.",
            "Raportti puuttuu. Sää jatkuu ilman valvontaa."
        ),
        PerunaTask(
            "T003",
            "Ajattele yhtä asiaa, jota et tule koskaan tekemään.",
            "Ajatus kirjattu. Se arkistoidaan kansioon ”Ei koskaan”. Kansio on jo melko täynnä.",
            "Ajattelu evätty. Se on tässäkin tapauksessa tehokasta."
        ),
        PerunaTask(
            "T004",
            "Katso lähintä mukia. Älä tee mitään. Raportoi onnistumisesta.",
            "Onnistuminen vahvistettu. Muki ei vastustanut.",
            "Mukia ei katsottu. Muki jatkaa ilman valvontaa. Se on tottunut."
        ),
        PerunaTask(
            "T005",
            "Valitse huoneesta esine, joka vaikuttaa epäilyttävältä. Älä syytä sitä vielä.",
            "Esine on merkitty tarkkailuun. Tutkimus jatkuu. Syytteitä ei ole.",
            "Kaikki esineet on toistaiseksi vapautettu epäilyksestä. Yksi niistä tietää."
        ),
        PerunaTask(
            "T006",
            "Taputa kevyesti lähintä pehmeää esinettä ja sano ”hyvä”.",
            "Esine on saanut tunnustusta. Se ei näytä sitä.",
            "Tunnustus evätty. Esine kestää sen. Esineet kestävät."
        ),
        PerunaTask(
            "T007",
            "Laske kaikki ovet, jotka näet. Älä kerro lukumäärää kenellekään.",
            "Lukumäärä on tallennettu. Se on salainen. Se on myös tylsä.",
            "Ovet jäävät laskematta. Ne ovat yhä siellä. PERUNA ei syytä."
        ),
        PerunaTask(
            "T008",
            "Sulje silmäsi viideksi sekunniksi. Kuvittele kokous, joka on peruttu.",
            "Peruutus onnistui. Tuntuu hyvältä. Älä tee tästä tapaa.",
            "Kokous ei peruuntunut. Se on jo alkanut. Sinua ei ole kuultu."
        ),
        PerunaTask(
            "T009",
            "Sano yksi lause ääneen täysin viralliseen sävyyn. Esimerkiksi: ”Asia on käsitelty.”",
            "Lause kuultu. Se kuulosti virkamieheltä. Virkamies on tyytyväinen.",
            "Ääntä ei kuultu. Asia on käsitelty hiljaisuudessa. Se on myös virallista."
        ),
        PerunaTask(
            "T010",
            "Järjestä yksi lähellä oleva esine kohtisuoraan toisen esineen kanssa.",
            "Kohtisuoruus todennettu. Maailma on hetken selkeämpi.",
            "Vinous säilytetty. Se oli suunniteltua."
        ),
        PerunaTask(
            "T011",
            "Juo kulaus vettä kuin se olisi virallinen toimenpide.",
            "Toimenpide suoritettu. Neste kirjattu. Kukaan ei taputtanut.",
            "Vesi jää nauttimatta. Se odottaa kärsivällisesti, kuten vesi yleensä."
        ),
        PerunaTask(
            "T012",
            "Nimeä lähin huonekasvi tai esine virallisella arvonimellä.",
            "Arvonimi vahvistettu. Se ei ole palkkaluokassa, mutta kunnia on todellinen.",
            "Nimeämättä jäänyt kohde jatkaa nimettömänä. Se on tottunut."
        ),
        PerunaTask(
            "T013",
            "Kävele huoneen poikki hitaasti ja tarkoituksella. Pysähdy keskelle. Jatka.",
            "Kävely hyväksytty. Suunta oli oikea. Määränpää oli epäselvä.",
            "Paikallaanolo kirjattu. Se on myös liikettä, hieman."
        ),
        PerunaTask(
            "T014",
            "Mieti kolme sanaa, jotka kuvaavat tämän päivän tunnelmaa. Älä käytä sanaa ”ok”.",
            "Sanat vastaanotettu. Ne eivät olleet kovin yllättäviä, mutta ne olivat sinun.",
            "Sanat jäivät keksimättä. Tunnelma jäi kuvaamatta. Se on oikeastaan sama asia."
        ),
        PerunaTask(
            "T015",
            "Tarkista, onko jääkaappi edelleen siellä, missä se oli.",
            "Jääkaappi on paikoillaan. Tämä on rauhoittava havainto, ja siitä kerrotaan harvoin.",
            "Jääkaappi on silti siellä. Se ei tarvitse sinun tarkistustasi. Se vain on."
        ),
        PerunaTask(
            "T016",
            "Nosta yksi sormi ilmaan ja perustele päätöksesi.",
            "Perustelu: ”Näin piti tehdä.” Hyväksytty.",
            "Sormi lasketaan. Perustelua ei vaadita. Sormi ei ole ylpeä."
        ),
        PerunaTask(
            "T017",
            "Etsi lähistöltä jokin sininen esine. Jos sellaista ei löydy, ilmoita siitä.",
            "Sininen esine on kirjattu. Muut värit eivät ole tässä mukana.",
            "Sininen on edelleen väri. Sitä ei tarvitse löytää, mutta se on olemassa."
        ),
        PerunaTask(
            "T018",
            "Kuiskaa sana ”asiakirja” kuin se olisi salasana.",
            "Salasana hyväksytty. Mikään ei auennut. Tämä on normaalia.",
            "Salasanaa ei sanottu. Mikään ei auennut. Tämä on myös normaalia."
        ),
        PerunaTask(
            "T019",
            "Suorista asentosi ja ilmoita itsellesi: ”Olen paikalla.”",
            "Läsnäolo vahvistettu. Läsnäolon laatu: riittävä.",
            "Poissaolo kirjattu. Syy: ei ilmoitettu. Seuraamus: ei mitään."
        ),
        PerunaTask(
            "T020",
            "Valitse tänään yksi sana, jota käytät vain virallisissa asioissa.",
            "Sana on varattu. Käytä sitä harkiten, vaikka kukaan ei tarkista.",
            "Sanavarasto jäi ennalleen. Se on riittävä."
        ),
        PerunaTask(
            "T021",
            "Keksi yksi turha sääntö omalle huoneellesi. Noudata sitä viisi minuuttia.",
            "Sääntö noudatettu. Kukaan ei valittanut. Sääntö jää voimaan toistaiseksi.",
            "Sääntöä ei otettu käyttöön. Huone jää anarkiaan."
        ),
        PerunaTask(
            "T022",
            "Vaihda kahden esineen paikkaa keskenään. Syytä ei tarvita.",
            "Vaihto suoritettu. Esineet ovat hämmentyneitä mutta sopeutuvat.",
            "Esineet saavat pysyä paikoillaan. Ne eivät tienneet olleensa vaarassa."
        ),
        PerunaTask(
            "T023",
            "Katso kelloa ja päätä, onko se sinun puolellasi.",
            "Päätös kirjattu. Kello ei kommentoinut.",
            "Kello jäi tarkistamatta. Aika kuluu, vaikka et katso. Sille on kehitetty tapa."
        ),
        PerunaTask(
            "T024",
            "Taputa itseäsi kevyesti olkapäähän. Tämä on virallinen kehu.",
            "Kehu annettu ja vastaanotettu. Molemmat osapuolet ovat tyytyväisiä.",
            "Kehu jää antamatta. Se säilytetään arkistossa tulevaa käyttöä varten."
        ),
        PerunaTask(
            "T025",
            "Laske hitaasti kolmeen. Ilmoita, mitä tapahtui.",
            "Laskenta onnistui. Tapahtui kolme. Ei enempää.",
            "Laskenta keskeytettiin. Luku kolme jää vapaaksi jonkun toisen käyttöön."
        ),
        PerunaTask(
            "T026",
            "Sulje yksi välilehti, jota et tarvitse. Tai harkitse sitä vain.",
            "Välilehti suljettu tai harkittu. Kumpikin tuottaa helpotusta.",
            "Välilehdet jäävät auki. Ne ovat sinun perintösi."
        ),
        PerunaTask(
            "T027",
            "Sano ”kiitos” jollekin esineelle, joka on tänään ollut luotettava.",
            "Kiitos vastaanotettu. Esine ei vastannut. Se on esineen tapa osoittaa kunnioitusta.",
            "Kiitosta ei annettu. Esine on tottunut. Se ei vaadi."
        ),
        PerunaTask(
            "T028",
            "Selvitä katsomalla, onko lähin ovi auki vai kiinni. Kirjaa tulos mielessäsi.",
            "Mittaus suoritettu. Tulos: ovi on joko auki tai kiinni. Tarkkuus erinomainen.",
            "Ovi jäi tarkastamatta. Se on edelleen ovi."
        ),
        PerunaTask(
            "T029",
            "Pyöräytä katsettasi hitaasti ympäri huonetta kuin tarkastaja.",
            "Tarkastus suoritettu. Löydöksiä: huone. Huomautuksia: ei.",
            "Tarkastus siirretty. Huone kiittää."
        ),
        PerunaTask(
            "T030",
            "Päätä, mikä on tämän hetken tärkein esine. Älä kerro kenellekään.",
            "Valinta vahvistettu. Esine ei tiedä asemastaan. Pidä se niin.",
            "Tärkein esine jäi valitsematta. Kaikki esineet ovat siitä helpottuneita."
        ),
        PerunaTask(
            "T031",
            "Kirjoita ilmaan yksi sana. Sana saa olla mikä tahansa. Se ei jää voimaan.",
            "Sana luettu. Se oli vähän vino, mutta ymmärrettävä.",
            "Ilma jäi kirjoittamatta. Se ei ole pettynyt. Se on ilmaa."
        ),
        PerunaTask(
            "T032",
            "Mieti, mikä on tämän päivän tärkein päätös. Älä tee sitä.",
            "Päätös lykätty. Lykkääminen on kirjattu asiantuntijatasoksi.",
            "Päätös tehtiin heti. Tämä ei ollut ohjeen mukaista. Hyvä silti."
        ),
        PerunaTask(
            "T033",
            "Katso ylös. Katso sitten alas. Raportoi, kumpi oli parempi.",
            "Raportti kirjattu. Ylös ja alas ovat nyt tasapisteissä.",
            "Suuntia ei vertailtu. Ne jatkavat ilman arviointia."
        ),
        PerunaTask(
            "T034",
            "Hengitä sisään kuin olisit saanut hyviä uutisia.",
            "Hyvät uutiset vastaanotettu. Niiden sisältö jäi epäselväksi. Hengitys oli silti hyväksyttävä.",
            "Uutisia ei vastaanotettu. Ne odottavat jonossa. Jono on lyhyt."
        ),
    )

    val statusLines: List<String> = listOf(
        "Järjestelmä toimii. Syytä ei tiedetä.",
        "Ladataan asiantuntemusta... 3 %",
        "Arkistoidaan arkistoja...",
        "Tarkistetaan tarkistuksia...",
        "Odotetaan odottamista...",
        "Muisti: täynnä, mutta ei tärkeää.",
        "Virallista hölynpölyä vuodesta 1998.",
        "Kellarin tila: ennallaan.",
        "Perunat paikalla: 1/1.",
        "Käyttäjä tunnistettu: suunnilleen.",
        "Kahvia ei löytynyt. Jatketaan silti.",
        "Tulostus: ei tulostinta.",
        "Seuraava päivitys: ei tiedossa.",
        "Tuomiovarasto: riittävä.",
        "Leimasin: kuiva mutta toimiva.",
        "Verkkoyhteys: ei, ei koskaan, kiitos.",
        "Tilanne: kunnossa tai sinnepäin.",
        "Kansio ”Muut” on kasvanut.",
    )

    val reliabilityLabels: List<String> = listOf(
        "PERUNALLINEN",
        "SUUNNILLEEN TÄSMÄLLINEN",
        "VAHVISTAMATON (MUTTA VAKUUTTAVA)",
        "HYVÄKSYTTY ILMAN TARKISTUSTA",
        "KOHTALAISEN KESKEN",
        "VIRALLISESTI VÄHÄN VÄÄRIN",
        "TARKISTETTU KERRAN (KUKAAN EI MUISTA)",
        "EPÄVIRALLISEN VIRALLINEN",
        "TILASTOLLISESTI TUNNELMALLINEN",
        "MITTAAMATON",
        "PERUNALLINEN",
    )

    val stamps: List<String> = listOf(
        "HYVÄKSYTTY",
        "KÄSITELTY",
        "KIRJATTU",
        "ARKISTOITU",
        "EI TARKISTETTU",
        "LEIMATTU",
        "VIRALLINEN",
        "KUITATTU",
    )
}
