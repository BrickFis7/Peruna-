package fi.peruna.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import fi.peruna.app.ui.theme.PerunaColors

/** Retrohenkinen 3D-reunus: vaaleat reunat ylä- ja vasemmalla, tummat alhaalla ja oikealla. */
fun Modifier.bevel(raised: Boolean = true, thickness: Dp = 3.dp): Modifier = this.drawBehind {
    val t = thickness.toPx()
    val light = if (raised) PerunaColors.ChromeLight else PerunaColors.ChromeDark
    val dark = if (raised) PerunaColors.ChromeDark else PerunaColors.ChromeLight
    drawRect(light, topLeft = Offset(0f, 0f), size = Size(size.width, t))
    drawRect(light, topLeft = Offset(0f, 0f), size = Size(t, size.height))
    drawRect(dark, topLeft = Offset(0f, size.height - t), size = Size(size.width, t))
    drawRect(dark, topLeft = Offset(size.width - t, 0f), size = Size(t, size.height))
}

enum class ButtonKind { Normal, Primary, Danger }

@Composable
fun RetroButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.Normal,
    fontSize: TextUnit = 16.sp
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val background = when (kind) {
        ButtonKind.Primary -> PerunaColors.Olive
        ButtonKind.Danger -> PerunaColors.Stamp
        ButtonKind.Normal -> PerunaColors.Chrome
    }
    val foreground = when (kind) {
        ButtonKind.Primary -> PerunaColors.Terminal
        ButtonKind.Danger -> Color.White
        ButtonKind.Normal -> PerunaColors.Ink
    }
    Box(
        modifier = modifier
            .heightIn(min = 52.dp)
            .background(background)
            .bevel(raised = !pressed)
            .clickable(
                interactionSource = source,
                indication = null,
                role = Role.Button,
                onClick = onClick
            )
            .padding(horizontal = 10.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = foreground,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize,
            textAlign = TextAlign.Center,
            modifier = Modifier.offset(y = if (pressed) 2.dp else 0.dp)
        )
    }
}

@Composable
fun RetroWindow(
    title: String,
    modifier: Modifier = Modifier,
    titleModifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .background(PerunaColors.Chrome)
            .bevel(raised = true)
            .padding(3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PerunaColors.Olive)
                .heightIn(min = 44.dp)
                .padding(start = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = PerunaColors.Terminal,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = titleModifier.weight(1f)
            )
            if (onClose != null) {
                CloseBox(onClose)
            }
        }
        content()
    }
}

@Composable
private fun CloseBox(onClose: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    Box(
        modifier = Modifier
            .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
            .clickable(
                interactionSource = source,
                indication = null,
                role = Role.Button,
                onClickLabel = "Takaisin",
                onClick = onClose
            )
            .padding(6.dp)
            .background(PerunaColors.Chrome)
            .bevel(raised = !pressed, thickness = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "×",
            color = PerunaColors.Ink,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )
    }
}

/** Vaalea "paperi"-paneeli, jossa asiakirjat näytetään. */
@Composable
fun PaperPanel(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .background(PerunaColors.Paper)
            .bevel(raised = false)
            .padding(14.dp),
        content = content
    )
}

/** Punainen kumileimasin. */
@Composable
fun Stamp(text: String, modifier: Modifier = Modifier) {
    val color = PerunaColors.Stamp.copy(alpha = 0.88f)
    Box(
        modifier = modifier
            .rotate(-8f)
            .border(3.dp, color)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun MonoLabel(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = PerunaColors.InkSoft,
    fontSize: TextUnit = 13.sp,
    bold: Boolean = true
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontFamily = FontFamily.Monospace,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontSize = fontSize
    )
}

@Composable
fun Rule(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .heightIn(min = 2.dp, max = 2.dp)
            .background(PerunaColors.Ink)
    )
}

@Composable
fun RetroDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismissText: String? = null,
    danger: Boolean = false
) {
    Dialog(onDismissRequest = onDismiss) {
        RetroWindow(title = title, modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .background(PerunaColors.Paper)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = message,
                    color = PerunaColors.Ink,
                    fontSize = 16.sp,
                    lineHeight = 22.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (dismissText != null) {
                        RetroButton(
                            text = dismissText,
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    RetroButton(
                        text = confirmText,
                        onClick = onConfirm,
                        modifier = Modifier.weight(1f),
                        kind = if (danger) ButtonKind.Danger else ButtonKind.Primary
                    )
                }
            }
        }
    }
}
