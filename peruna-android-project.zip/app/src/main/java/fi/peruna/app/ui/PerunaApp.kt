package fi.peruna.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.ui.theme.PerunaColors
import kotlinx.coroutines.delay

@Composable
fun PerunaApp(state: AppState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PerunaColors.Chrome)
    ) {
        // Oliivinvihreät palkit järjestelmäpalkkien alla (toimii myös reunasta reunaan -tilassa).
        Spacer(
            Modifier
                .fillMaxWidth()
                .windowInsetsTopHeight(WindowInsets.statusBars)
                .background(PerunaColors.Olive)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .displayCutoutPadding()
        ) {
            Crossfade(
                targetState = state.screen,
                animationSpec = tween(durationMillis = 160),
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.HOME -> HomeScreen(state)
                    Screen.JUDGMENT -> JudgmentScreen(state)
                    Screen.TASK -> TaskScreen(state)
                    Screen.ACHIEVEMENTS -> AchievementsScreen(state)
                    Screen.SETTINGS -> SettingsScreen(state)
                }
            }

            AchievementBanner(state, Modifier.align(Alignment.TopCenter))
        }

        Spacer(
            Modifier
                .fillMaxWidth()
                .windowInsetsBottomHeight(WindowInsets.navigationBars)
                .background(PerunaColors.Olive)
        )
    }
}

/** Pieni ilmoitus avatusta saavutuksesta. Näytetään yksi kerrallaan ja kunkin vain kerran. */
@Composable
private fun AchievementBanner(state: AppState, modifier: Modifier) {
    val first = state.banner.firstOrNull()
    if (first != null) {
        LaunchedEffect(first.id) {
            delay(3500)
            state.dismissBanner()
        }
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(10.dp)
                .background(PerunaColors.OliveDark)
                .bevel(raised = true)
                .clickable { state.dismissBanner() }
                .padding(14.dp)
        ) {
            Text(
                text = "SAAVUTUS AVATTU",
                color = PerunaColors.Terminal,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = first.title,
                color = androidx.compose.ui.graphics.Color.White,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Text(
                text = first.description,
                color = PerunaColors.Paper,
                fontSize = 14.sp,
                lineHeight = 19.sp
            )
        }
    }
}
