package fi.peruna.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object PerunaColors {
    val Chrome = Color(0xFFC9C5B8)
    val ChromeLight = Color(0xFFF2F0E8)
    val ChromeDark = Color(0xFF7A766B)
    val Olive = Color(0xFF3F4A2A)
    val OliveDark = Color(0xFF2A331C)
    val Terminal = Color(0xFF9BE564)
    val Paper = Color(0xFFF6F3E7)
    val Ink = Color(0xFF1F1F1A)
    val InkSoft = Color(0xFF4A4A40)
    val Stamp = Color(0xFFB3261E)
    val Potato = Color(0xFFD9B26A)
    val PotatoDark = Color(0xFF6B4F1D)
}

private val PerunaColorScheme = lightColorScheme(
    primary = PerunaColors.Olive,
    onPrimary = PerunaColors.Terminal,
    secondary = PerunaColors.Stamp,
    background = PerunaColors.Chrome,
    onBackground = PerunaColors.Ink,
    surface = PerunaColors.Paper,
    onSurface = PerunaColors.Ink,
    error = PerunaColors.Stamp
)

@Composable
fun PerunaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PerunaColorScheme,
        content = content
    )
}
