package fi.peruna.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fi.peruna.app.BuildConfig
import fi.peruna.app.data.Achievements
import fi.peruna.app.data.Content
import fi.peruna.app.ui.theme.PerunaColors
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun HomeScreen(state: AppState) {
    var versionTaps by remember { mutableIntStateOf(0) }
    var showEgg by remember { mutableStateOf(false) }
    var statusIndex by remember { mutableIntStateOf(Random.nextInt(Content.statusLines.size)) }

    // Vaihtuva tilarivi. Hidas ja rauhallinen: ei välkkymistä.
    LaunchedEffect(Unit) {
        while (true) {
            delay(4500)
            statusIndex = (statusIndex + 1) % Content.statusLines.size
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RetroWindow(
            title = "PERUNA OS / v${BuildConfig.VERSION_NAME}",
            modifier = Modifier.fillMaxWidth(),
            titleModifier = Modifier.clickable {
                // Piilotettu pääsiäismuna: napauta versiotekstiä 7 kertaa.
                versionTaps += 1
                if (versionTaps >= 7) {
                    versionTaps = 0
                    state.addFlag(Achievements.FLAG_EGG_VERSION)
                    showEgg = true
                }
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PerunaMascot(mood = Mood.DEADPAN, modifier = Modifier.size(170.dp))

                Text(
                    text = "PERUNA™",
                    color = PerunaColors.Olive,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 38.sp,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Elämänhallintaa, mutta väärin.",
                    color = PerunaColors.Ink,
                    fontSize = 16.sp,
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center
                )

                // Tilarivi (terminaalityyli)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PerunaColors.OliveDark)
                        .bevel(raised = false, thickness = 2.dp)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "> " + Content.statusLines[statusIndex],
                        color = PerunaColors.Terminal,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }

                RetroButton(
                    text = "ANNA TUOMIO",
                    onClick = { state.giveJudgment() },
                    modifier = Modifier.fillMaxWidth(),
                    kind = ButtonKind.Primary,
                    fontSize = 22.sp
                )
                RetroButton(
                    text = "ANNA HYÖDYTÖN TEHTÄVÄ",
                    onClick = { state.giveTask() },
                    modifier = Modifier.fillMaxWidth()
                )
                RetroButton(
                    text = "PÄIVÄN TUOMIO",
                    onClick = { state.giveDailyJudgment() },
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 14.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RetroButton(
                        text = "SAAVUTUKSET " + state.progress.unlockedAchievementIds.size +
                            "/" + Achievements.all.size,
                        onClick = { state.openAchievements() },
                        modifier = Modifier.weight(1f),
                        fontSize = 13.sp
                    )
                    RetroButton(
                        text = "ASETUKSET",
                        onClick = { state.openSettings() },
                        modifier = Modifier.weight(1f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        Text(
            text = "Virallista hölynpölyä vuodesta 1998.",
            color = PerunaColors.InkSoft,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }

    if (showEgg) {
        RetroDialog(
            title = "SALAINEN VALIKKO",
            message = "Löysit piilotetun valikon. Valikossa ei ole mitään. Tämä on valikon ainoa ominaisuus.",
            confirmText = "OK, EI MITÄÄN",
            onConfirm = { showEgg = false },
            onDismiss = { showEgg = false }
        )
    }
}
