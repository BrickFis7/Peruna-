package fi.peruna.app.data

import kotlin.random.Random

/**
 * Valitsee seuraavan tuomion. Ei riipu Androidista, joten tämän voi testata tavallisilla yksikkötesteillä.
 */
object JudgmentRepository {

    /** Kuinka monta viimeisintä tuomiota ei toisteta. Tuomioita on selvästi enemmän kuin tämä. */
    const val RECENT_LIMIT = 40

    /** Todennäköisyys (prosenttia) satunnaiselle salaiselle tapahtumalle yhden tuomion kohdalla. */
    const val SECRET_CHANCE_PERCENT = 4

    /** Harvinaisen tuomion paino tavalliseen verrattuna (1.0). */
    private const val RARE_WEIGHT = 0.6

    /** Virstanpylväät: monennella tuomiolla tulee mikäkin salainen tuomio. */
    val milestones: Map<Int, String> = mapOf(
        10 to "S01",
        42 to "S02",
        100 to "S03"
    )

    private val byIdMap: Map<String, Judgment> = Content.judgments.associateBy { it.id }

    /** Tavallinen + harvinainen valikoima. */
    val pool: List<Judgment> = Content.judgments.filter { it.rarity != Rarity.SECRET }

    /** Salaiset tuomiot, jotka voivat tulla satunnaisesti (ei virstanpylväät). */
    private val randomSecrets: List<Judgment> =
        Content.judgments.filter { it.rarity == Rarity.SECRET && it.id !in milestones.values }

    fun byId(id: String): Judgment? = byIdMap[id]

    /** Arvo seuraava tuomio nykyisen edistymisen perusteella. */
    fun draw(progress: AppProgress, random: Random): Judgment {
        val nextCount = progress.judgmentCount + 1

        // 1) Virstanpylväs
        val milestoneId = milestones[nextCount]
        if (milestoneId != null) {
            val milestone = byIdMap[milestoneId]
            if (milestone != null) return milestone
        }

        // 2) Satunnainen salainen tapahtuma (vain kerran per tuomio, ei aivan alussa)
        if (nextCount > 5 && random.nextInt(100) < SECRET_CHANCE_PERCENT) {
            val unseen = randomSecrets.filter {
                (Achievements.SECRET_PREFIX + it.id) !in progress.secretFlags
            }
            if (unseen.isNotEmpty()) return unseen[random.nextInt(unseen.size)]
        }

        // 3) Tavallinen arvonta ilman viimeisimpiä
        val recent = progress.recentJudgmentIds.take(RECENT_LIMIT).toSet()
        var candidates = pool.filter { it.id !in recent }
        if (candidates.isEmpty()) candidates = pool
        return pickWeighted(candidates, random)
    }

    /** Päivän tuomio: sama jokaiselle samana päivänä. Ei koskaan harvinainen eikä salainen. */
    fun forDay(epochDay: Long): Judgment {
        val daily = pool.filter { it.rarity == Rarity.COMMON }.sortedBy { it.id }
        val index = Math.floorMod(epochDay * 7919L + 13L, daily.size.toLong()).toInt()
        return daily[index]
    }

    private fun weightOf(j: Judgment): Double =
        if (j.rarity == Rarity.RARE) RARE_WEIGHT else 1.0

    private fun pickWeighted(items: List<Judgment>, random: Random): Judgment {
        var total = 0.0
        for (item in items) total += weightOf(item)
        var roll = random.nextDouble() * total
        for (item in items) {
            roll -= weightOf(item)
            if (roll <= 0.0) return item
        }
        return items.last()
    }
}
