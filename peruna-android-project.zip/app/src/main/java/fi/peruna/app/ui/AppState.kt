package fi.peruna.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import fi.peruna.app.data.Achievement
import fi.peruna.app.data.Achievements
import fi.peruna.app.data.AppProgress
import fi.peruna.app.data.Content
import fi.peruna.app.data.Judgment
import fi.peruna.app.data.JudgmentRepository
import fi.peruna.app.data.PerunaTask
import fi.peruna.app.data.ProgressRepository
import fi.peruna.app.data.Rarity
import fi.peruna.app.data.ShownJudgment
import fi.peruna.app.data.TaskAnswer
import fi.peruna.app.data.TaskRepository
import java.time.LocalDate
import kotlin.random.Random

enum class Screen { HOME, JUDGMENT, TASK, ACHIEVEMENTS, SETTINGS }

/**
 * Sovelluksen koko tila yhdessä paikassa: nykyinen näkymä, näytettävä tuomio/tehtävä ja edistyminen.
 * Kaikki muutokset tallennetaan heti puhelimen muistiin.
 */
class AppState(private val repo: ProgressRepository) {

    private val random: Random = Random.Default

    var progress: AppProgress by mutableStateOf(AppProgress())
        private set

    var screen: Screen by mutableStateOf(Screen.HOME)
        private set

    var shown: ShownJudgment? by mutableStateOf(null)
        private set

    var currentTask: PerunaTask? by mutableStateOf(null)
        private set

    var taskAnswer: TaskAnswer? by mutableStateOf(null)
        private set

    /** Jono avatuista saavutuksista, jotka odottavat ilmoitusta. Jokainen näytetään vain kerran. */
    val banner = mutableStateListOf<Achievement>()

    init {
        val loaded = repo.load()
        commit(loaded.copy(daysUsed = loaded.daysUsed + today()))
    }

    // ---------- Navigointi ----------

    fun goHome() {
        screen = Screen.HOME
    }

    fun openAchievements() {
        screen = Screen.ACHIEVEMENTS
        addFlag(Achievements.FLAG_VIEWED_ACHIEVEMENTS)
    }

    fun openSettings() {
        screen = Screen.SETTINGS
        addFlag(Achievements.FLAG_VIEWED_SETTINGS)
    }

    // ---------- Tuomiot ----------

    fun giveJudgment() {
        val judgment = JudgmentRepository.draw(progress, random)
        val count = progress.judgmentCount + 1
        present(judgment, daily = false, caseNumber = caseNumber(count), salt = count)
    }

    fun giveDailyJudgment() {
        val day = today()
        val judgment = JudgmentRepository.forDay(day)
        val case = dailyCaseNumber(day)
        if (progress.lastDailyDay == day) {
            // Jo laskettu tälle päivälle: näytä sama tuomio uudestaan, älä paisuta tilastoja.
            shown = buildShown(judgment, daily = true, caseNumber = case, salt = day.toInt())
            screen = Screen.JUDGMENT
        } else {
            present(judgment, daily = true, caseNumber = case, salt = day.toInt())
        }
    }

    private fun present(judgment: Judgment, daily: Boolean, caseNumber: String, salt: Int) {
        val p = progress
        var flags = p.secretFlags
        if (judgment.rarity == Rarity.SECRET) flags = flags + (Achievements.SECRET_PREFIX + judgment.id)
        if (daily) flags = flags + Achievements.FLAG_DAILY_SEEN

        shown = buildShown(judgment, daily, caseNumber, salt)
        screen = Screen.JUDGMENT

        commit(
            p.copy(
                judgmentCount = p.judgmentCount + 1,
                recentJudgmentIds = (listOf(judgment.id) + p.recentJudgmentIds)
                    .distinct()
                    .take(JudgmentRepository.RECENT_LIMIT),
                categoriesSeen = p.categoriesSeen + judgment.category,
                secretFlags = flags,
                lastDailyDay = if (daily) today() else p.lastDailyDay
            )
        )
    }

    private fun buildShown(judgment: Judgment, daily: Boolean, caseNumber: String, salt: Int): ShownJudgment {
        val seed = judgment.id.hashCode() + salt * 31
        return ShownJudgment(
            judgment = judgment,
            caseNumber = caseNumber,
            reliability = Content.reliabilityLabels[Math.floorMod(seed, Content.reliabilityLabels.size)],
            stamp = Content.stamps[Math.floorMod(seed / 7, Content.stamps.size)],
            isDaily = daily
        )
    }

    fun recordShare() {
        commit(progress.copy(shareCount = progress.shareCount + 1))
    }

    // ---------- Tehtävät ----------

    fun giveTask() {
        val p = progress
        val task = TaskRepository.draw(p, random)
        currentTask = task
        taskAnswer = null
        screen = Screen.TASK
        commit(
            p.copy(
                recentTaskIds = (listOf(task.id) + p.recentTaskIds)
                    .distinct()
                    .take(TaskRepository.RECENT_LIMIT)
            )
        )
    }

    fun answerTask(completed: Boolean) {
        val task = currentTask ?: return
        if (taskAnswer != null) return // vastaus lasketaan vain kerran per tehtävä
        val p = progress
        taskAnswer = TaskAnswer(
            completed = completed,
            response = if (completed) task.completedResponse else task.declinedResponse
        )
        commit(
            if (completed) p.copy(completedTaskCount = p.completedTaskCount + 1)
            else p.copy(declinedTaskCount = p.declinedTaskCount + 1)
        )
    }

    // ---------- Lippuja ja pääsiäismunia ----------

    fun addFlag(flag: String) {
        if (flag in progress.secretFlags) return
        commit(progress.copy(secretFlags = progress.secretFlags + flag))
    }

    fun dismissBanner() {
        if (banner.isNotEmpty()) banner.removeAt(0)
    }

    // ---------- Nollaus ----------

    fun resetProgress() {
        repo.reset()
        banner.clear()
        shown = null
        currentTask = null
        taskAnswer = null
        val fresh = AppProgress(daysUsed = setOf(today()))
        progress = fresh
        repo.save(fresh)
    }

    // ---------- Sisäiset apurit ----------

    /** Tallentaa uuden tilan ja avaa mahdolliset uudet saavutukset (jokainen vain kerran). */
    private fun commit(updated: AppProgress) {
        var next = updated
        val newly = Achievements.newlyUnlocked(next)
        if (newly.isNotEmpty()) {
            next = next.copy(
                unlockedAchievementIds = next.unlockedAchievementIds + newly.map { it.id }
            )
            banner.addAll(newly)
        }
        progress = next
        repo.save(next)
    }

    private fun today(): Long = LocalDate.now().toEpochDay()

    private fun caseNumber(count: Int): String = "PER/1998/" + count.toString().padStart(4, '0')

    private fun dailyCaseNumber(day: Long): String =
        "PÄIVÄ/1998/" + (day % 10000L).toString().padStart(4, '0')
}
