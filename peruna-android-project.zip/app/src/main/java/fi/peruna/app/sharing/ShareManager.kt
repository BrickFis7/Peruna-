package fi.peruna.app.sharing

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.core.content.FileProvider
import fi.peruna.app.BuildConfig
import fi.peruna.app.data.ShownJudgment
import java.io.File
import java.io.FileOutputStream

/** Jakaminen Androidin omalla jakovalikolla. Ei oikeuksia, ei verkkoa. */
object ShareManager {

    private const val TAGLINE = "Elämänhallintaa, mutta väärin."

    fun buildText(shown: ShownJudgment): String {
        val j = shown.judgment
        val sb = StringBuilder()
        sb.append("PERUNA™ — TAPAUS ").append(shown.caseNumber).append('\n')
        sb.append('[').append(j.category).append("]\n\n")
        sb.append(j.headline).append('\n')
        if (j.body.isNotBlank()) sb.append(j.body).append('\n')
        sb.append('\n')
        sb.append("LUOTETTAVUUS: ").append(shown.reliability).append('\n')
        sb.append("— PERUNA OS v").append(BuildConfig.VERSION_NAME).append(". ").append(TAGLINE)
        return sb.toString()
    }

    fun shareText(context: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        launchChooser(context, send)
    }

    /** Jakaa tuomion kuvakorttina. Jos kortin teko epäonnistuu, jaetaan tavallinen teksti. */
    fun shareCard(context: Context, shown: ShownJudgment) {
        val fallbackText = buildText(shown)
        try {
            val dir = File(context.cacheDir, "cards")
            dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() } // siivoa vanhat kortit

            val file = File(dir, "peruna_tuomio_" + System.currentTimeMillis() + ".png")
            val bitmap = CardRenderer.render(shown)
            try {
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            } finally {
                bitmap.recycle()
            }

            val uri = FileProvider.getUriForFile(
                context,
                context.packageName + ".fileprovider",
                file
            )
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "PERUNA™ — $TAGLINE")
                clipData = ClipData.newRawUri("PERUNA", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            launchChooser(context, send)
        } catch (e: Exception) {
            shareText(context, fallbackText)
        }
    }

    private fun launchChooser(context: Context, send: Intent) {
        val chooser = Intent.createChooser(send, "Jaa tuomio")
        if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(chooser)
        } catch (e: ActivityNotFoundException) {
            // Ei jakosovellusta: ei tehdä mitään, ettei sovellus kaadu.
        }
    }
}
