package fi.peruna.app.data

object Achievements {

    const val FLAG_EGG_VERSION = "egg_version"
    const val FLAG_VIEWED_SETTINGS = "viewed_settings"
    const val FLAG_VIEWED_ACHIEVEMENTS = "viewed_achievements"
    const val FLAG_DAILY_SEEN = "daily_seen"
    const val SECRET_PREFIX = "secret:"

    val all: List<Achievement> = listOf(
        Achievement(
            id = "A01",
            title = "ENSIMMÄINEN LAUSUNTO",
            description = "Asiakirja on avattu. Kukaan ei vielä tiedä miksi.",
            hint = "Pyydä yksi tuomio.",
            secret = false,
            unlockRule = { it.judgmentCount >= 1 }
        ),
        Achievement(
            id = "A02",
            title = "JÄÄKAAPPITUTKIJA",
            description = "Olet tarkastanut tilanteen kylmäosastolla.",
            hint = "Tarkista tilanne kolme kertaa.",
            secret = false,
            unlockRule = { it.judgmentCount >= 3 }
        ),
        Achievement(
            id = "A03",
            title = "KESKINKERTAISUUDEN ERIKOISASIANTUNTIJA",
            description = "Olet osoittanut tasaista epätasaisuutta.",
            hint = "Kymmenen tuomiota. Ei yhtään enempää, ei yhtään vähempää.",
            secret = false,
            unlockRule = { it.judgmentCount >= 10 }
        ),
        Achievement(
            id = "A04",
            title = "PERUNAN LUOTTAMUSHENKILÖ",
            description = "Luottamus on yksipuolista, mutta aitoa.",
            hint = "Kaksikymmentäviisi tuomiota luottamuksen rakentamiseksi.",
            secret = false,
            unlockRule = { it.judgmentCount >= 25 }
        ),
        Achievement(
            id = "A05",
            title = "PYSYVÄ ASIAKAS",
            description = "Sinulle on avattu oma kansio. Kansio on tyhjä, mutta se on sinun.",
            hint = "Viisikymmentä tuomiota. Kansio odottaa.",
            secret = false,
            unlockRule = { it.judgmentCount >= 50 }
        ),
        Achievement(
            id = "A06",
            title = "ARKISTON ARKISTOIJA",
            description = "Arkistoasi säilytetään arkistossa, jota ei ole.",
            hint = "Sata tuomiota. Arkisto ei vielä tiedä.",
            secret = false,
            unlockRule = { it.judgmentCount >= 100 }
        ),
        Achievement(
            id = "A07",
            title = "SIVUTEHTÄVÄN SUORITTAJA",
            description = "Päätehtävästä ei ole näyttöä.",
            hint = "Tee yksi hyödytön tehtävä.",
            secret = false,
            unlockRule = { it.completedTaskCount >= 1 }
        ),
        Achievement(
            id = "A08",
            title = "PIENTEN ASIOIDEN MESTARI",
            description = "Pienet asiat ovat tänään suuria. Tämä ei ole kehu.",
            hint = "Viisi tehtävää tehty.",
            secret = false,
            unlockRule = { it.completedTaskCount >= 5 }
        ),
        Achievement(
            id = "A09",
            title = "TARKOITUKSETON TYÖNTEKIJÄ",
            description = "Teet työtä, jonka tarkoitus on tuntematon. Silti teet.",
            hint = "Viisitoista tehtävää tehty.",
            secret = false,
            unlockRule = { it.completedTaskCount >= 15 }
        ),
        Achievement(
            id = "A10",
            title = "HUOMISEN ASIANTUNTIJA",
            description = "Olet siirtänyt asian tulevaisuuden vastuulle.",
            hint = "Älä tunnusta yhtä tehtävää.",
            secret = false,
            unlockRule = { it.declinedTaskCount >= 1 }
        ),
        Achievement(
            id = "A11",
            title = "SYSTEMAATTINEN KIELTÄYTYJÄ",
            description = "Kieltäytyminen on kirjattu. Se on kirjattu väärin, mutta kirjattu.",
            hint = "Kieltäydy viisi kertaa.",
            secret = false,
            unlockRule = { it.declinedTaskCount >= 5 }
        ),
        Achievement(
            id = "A12",
            title = "TASAPUOLINEN ASIAKAS",
            description = "Teet ja et tee. Tilasto on tasapainossa.",
            hint = "Tee kolme tehtävää ja kieltäydy kolmesta.",
            secret = false,
            unlockRule = { it.completedTaskCount >= 3 && it.declinedTaskCount >= 3 }
        ),
        Achievement(
            id = "A13",
            title = "JAKAJAN VASTUU",
            description = "Olet levittänyt virallista hölynpölyä. Vastuu on jaettu, mutta ei sinulle.",
            hint = "Jaa yksi tuomio.",
            secret = false,
            unlockRule = { it.shareCount >= 1 }
        ),
        Achievement(
            id = "A14",
            title = "PERUNAN TIEDOTTAJA",
            description = "Viestintä on avointa, jos vastaanottaja ei kysy mitään.",
            hint = "Jaa viisi tuomiota.",
            secret = false,
            unlockRule = { it.shareCount >= 5 }
        ),
        Achievement(
            id = "A15",
            title = "MONIPUOLINEN ASIAKAS",
            description = "Olet saanut kaikenlaista. Mikään ei ole auttanut.",
            hint = "Saa tuomio jokaisesta tavallisesta luokasta.",
            secret = false,
            unlockRule = { it.categoriesSeen.containsAll(Categories.normal) }
        ),
        Achievement(
            id = "A16",
            title = "PITKÄAIKAISASIAKAS",
            description = "Olet palannut usealla eri päivällä. Järjestelmä on hämmentynyt.",
            hint = "Käytä sovellusta kolmena eri päivänä.",
            secret = false,
            unlockRule = { it.daysUsed.size >= 3 }
        ),
        Achievement(
            id = "A17",
            title = "PÄIVÄN VASTAANOTTAJA",
            description = "Tämä tuomio on voimassa vain tänään. Huomenna uusi väärinkäsitys.",
            hint = "Pyydä päivän tuomio.",
            secret = false,
            unlockRule = { Achievements.FLAG_DAILY_SEEN in it.secretFlags }
        ),
        Achievement(
            id = "A18",
            title = "ASETUSTEN KATSELIJA",
            description = "Katsoit asetuksia. Mitään ei asetettu.",
            hint = "Avaa asetukset.",
            secret = false,
            unlockRule = { Achievements.FLAG_VIEWED_SETTINGS in it.secretFlags }
        ),
        Achievement(
            id = "A19",
            title = "ITSEARVIOIJA",
            description = "Tarkastelet saavutuksiasi. Kukaan muu ei tee sitä.",
            hint = "Avaa saavutuslista.",
            secret = false,
            unlockRule = { Achievements.FLAG_VIEWED_ACHIEVEMENTS in it.secretFlags }
        ),
        Achievement(
            id = "A20",
            title = "VERSIONUMERON TUTKIJA",
            description = "Tarkastit versionumeron. Se ei auttanut.",
            hint = "Jokin etusivulla kestää tarkempaa koskettelua.",
            secret = true,
            unlockRule = { Achievements.FLAG_EGG_VERSION in it.secretFlags }
        ),
        Achievement(
            id = "A21",
            title = "SALAISEN ASIAKIRJAN HALTIJA",
            description = "Löysit asiakirjan, jota ei ole olemassa.",
            hint = "Tämä asiakirja ei ole olemassa.",
            secret = true,
            unlockRule = { p -> p.secretFlags.any { it.startsWith(Achievements.SECRET_PREFIX) } }
        )
    )

    /** Palauttaa ne saavutukset, jotka täyttyvät mutta eivät ole vielä avattuja. */
    fun newlyUnlocked(progress: AppProgress): List<Achievement> =
        all.filter { it.id !in progress.unlockedAchievementIds && it.unlockRule(progress) }
}
