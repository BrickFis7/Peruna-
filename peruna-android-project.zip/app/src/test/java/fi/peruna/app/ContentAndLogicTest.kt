package fi.peruna.app

import fi.peruna.app.data.Achievements
import fi.peruna.app.data.AppProgress
import fi.peruna.app.data.Categories
import fi.peruna.app.data.Content
import fi.peruna.app.data.JudgmentRepository
import fi.peruna.app.data.Rarity
import fi.peruna.app.data.TaskRepository
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentAndLogicTest {

    @Test
    fun contentHasEnoughMaterial() {
        assertTrue("judgments", Content.judgments.size >= 100)
        assertTrue("tasks", Content.tasks.size >= 30)
        assertTrue("achievements", Achievements.all.size >= 10)
    }

    @Test
    fun idsAreUniqueAndSafe() {
        val ids = Content.judgments.map { it.id } + Content.tasks.map { it.id } + Achievements.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(ids.none { it.contains(",") || it.isBlank() })
    }

    @Test
    fun noEmptyTexts() {
        assertTrue(Content.judgments.all { it.headline.isNotBlank() })
        assertTrue(Content.tasks.all { it.prompt.isNotBlank() && it.completedResponse.isNotBlank() && it.declinedResponse.isNotBlank() })
        assertTrue(Content.statusLines.isNotEmpty() && Content.reliabilityLabels.isNotEmpty() && Content.stamps.isNotEmpty())
    }

    @Test
    fun commonJudgmentsUseKnownCategories() {
        val common = Content.judgments.filter { it.rarity == Rarity.COMMON }
        assertTrue(common.all { it.category in Categories.normal })
        assertEquals(Categories.normal.toSet(), common.map { it.category }.toSet())
    }

    @Test
    fun milestoneJudgmentsExist() {
        for ((_, id) in JudgmentRepository.milestones) {
            assertNotNull(JudgmentRepository.byId(id))
            assertEquals(Rarity.SECRET, JudgmentRepository.byId(id)!!.rarity)
        }
    }

    @Test
    fun milestoneAppearsOnTenthJudgment() {
        val p = AppProgress(judgmentCount = 9)
        assertEquals("S01", JudgmentRepository.draw(p, Random(1)).id)
    }

    @Test
    fun recentJudgmentsAreNotRepeated() {
        val random = Random(12345)
        var progress = AppProgress()
        val history = ArrayList<String>()
        repeat(300) {
            val j = JudgmentRepository.draw(progress, random)
            val window = history.takeLast(JudgmentRepository.RECENT_LIMIT)
            // Salaiset tapahtumat saavat tulla milloin vain; tavallisia ei saa toistaa liian pian.
            if (j.rarity != Rarity.SECRET) {
                assertFalse("repeat of ${j.id}", j.id in window)
            }
            history.add(j.id)
            progress = progress.copy(
                judgmentCount = progress.judgmentCount + 1,
                recentJudgmentIds = (listOf(j.id) + progress.recentJudgmentIds).distinct().take(JudgmentRepository.RECENT_LIMIT)
            )
        }
    }

    @Test
    fun rareJudgmentsDoShowUpEventually() {
        val random = Random(7)
        var progress = AppProgress()
        var rareSeen = 0
        repeat(300) {
            val j = JudgmentRepository.draw(progress, random)
            if (j.rarity == Rarity.RARE) rareSeen++
            progress = progress.copy(
                judgmentCount = progress.judgmentCount + 1,
                recentJudgmentIds = (listOf(j.id) + progress.recentJudgmentIds).distinct().take(JudgmentRepository.RECENT_LIMIT)
            )
        }
        assertTrue("rare seen: $rareSeen", rareSeen > 0)
    }

    @Test
    fun dailyJudgmentIsStableForTheSameDay() {
        assertEquals(JudgmentRepository.forDay(20000L).id, JudgmentRepository.forDay(20000L).id)
        assertEquals(Rarity.COMMON, JudgmentRepository.forDay(20001L).rarity)
    }

    @Test
    fun tasksAvoidRecentOnes() {
        val random = Random(99)
        val recent = TaskRepository.all.take(TaskRepository.RECENT_LIMIT).map { it.id }
        val t = TaskRepository.draw(AppProgress(recentTaskIds = recent), random)
        assertFalse(t.id in recent)
    }

    @Test
    fun achievementsUnlockByRules() {
        assertTrue(Achievements.newlyUnlocked(AppProgress()).isEmpty())

        val first = Achievements.newlyUnlocked(AppProgress(judgmentCount = 1)).map { it.id }
        assertTrue("A01" in first)

        val task = Achievements.newlyUnlocked(AppProgress(completedTaskCount = 1)).map { it.id }
        assertTrue("A07" in task)

        val declined = Achievements.newlyUnlocked(AppProgress(declinedTaskCount = 1)).map { it.id }
        assertTrue("A10" in declined)

        val secret = Achievements.newlyUnlocked(
            AppProgress(secretFlags = setOf(Achievements.SECRET_PREFIX + "S04"))
        ).map { it.id }
        assertTrue("A21" in secret)
    }

    @Test
    fun alreadyUnlockedAchievementsAreNotReported() {
        val p = AppProgress(judgmentCount = 1, unlockedAchievementIds = setOf("A01"))
        assertFalse(Achievements.newlyUnlocked(p).any { it.id == "A01" })
    }
}
